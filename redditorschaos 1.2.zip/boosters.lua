SMODS.Booster {
    key = 'jumbo_mahjong_pack',
    loc_txt = {
        name = "Jumbo Mahjong Pack",
        text = {
            "choose 1 of 4 Mahjong jokers"
        },
        group_name = "Jumbo Mahjong Pack"
    },
    config = { extra = 4, choose = 1 },
    cost = 6,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        rarity = "redditor_mahjong",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_jumbo_mahjong_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'jumbo_negative_pack',
    loc_txt = {
        name = "Jumbo Negative Pack",
        text = {
            "Choose 1 of 4 Negative jokers"
        },
        group_name = "Jumbo Negative Pack"
    },
    config = { extra = 4, choose = 1 },
    cost = 12,
    atlas = "CustomBoosters",
    pos = { x = 1, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        edition = "e_negative",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_jumbo_negative_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'jumbo_pride_pack',
    loc_txt = {
        name = "Jumbo Pride Pack",
        text = {
            "Choose 1 of 4 Polychrome jokers"
        },
        group_name = "Jumbo Pride Pack"
    },
    config = { extra = 4, choose = 1 },
    cost = 12,
    atlas = "CustomBoosters",
    pos = { x = 2, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        edition = "e_polychrome",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_jumbo_pride_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mahjong_pack',
    loc_txt = {
        name = "Mahjong Pack",
        text = {
            "choose 1 of 3 Mahjong jokers"
        },
        group_name = "Mahjong Pack"
    },
    config = { extra = 3, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 3, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        rarity = "redditor_mahjong",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_mahjong_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mega_mahjong_pack',
    loc_txt = {
        name = "Mega Mahjong Pack",
        text = {
            "choose 2 of 4 Mahjong jokers"
        },
        group_name = "Mega Mahjong Pack"
    },
    config = { extra = 4, choose = 2 },
    cost = 8,
    atlas = "CustomBoosters",
    pos = { x = 4, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        rarity = "redditor_mahjong",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_mega_mahjong_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mega_negative_pack',
    loc_txt = {
        name = "Mega Negative Pack",
        text = {
            "Choose 2 of 4 Negative jokers"
        },
        group_name = "Mega Negative Pack"
    },
    config = { extra = 4, choose = 2 },
    cost = 14,
    atlas = "CustomBoosters",
    pos = { x = 5, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        edition = "e_negative",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_mega_negative_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mega_pride_pack',
    loc_txt = {
        name = "Mega Pride Pack",
        text = {
            "Choose 2 of 4 Polychrome jokers"
        },
        group_name = "Mega Pride Pack"
    },
    config = { extra = 4, choose = 2 },
    cost = 16,
    atlas = "CustomBoosters",
    pos = { x = 6, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        edition = "e_polychrome",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_mega_pride_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'negative_pack',
    loc_txt = {
        name = "Negative pack",
        text = {
            "Choose 1 of 3 Negative jokers"
        },
        group_name = "Negative pack"
    },
    config = { extra = 3, choose = 1 },
    cost = 10,
    atlas = "CustomBoosters",
    pos = { x = 7, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        edition = "e_negative",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_negative_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'pride_pack',
    loc_txt = {
        name = "Pride Pack",
        text = {
            "Choose 1 of 3 Polychrome jokers"
        },
        group_name = "Pride Pack"
    },
    config = { extra = 3, choose = 1 },
    cost = 8,
    atlas = "CustomBoosters",
    pos = { x = 8, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        edition = "e_polychrome",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_pride_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'titan_pack',
    loc_txt = {
        name = "Titan Pack",
        text = {
            "Choose 1 of 3 Legendary jokers"
        },
        group_name = "Titan Pack"
    },
    config = { extra = 3, choose = 1 },
    cost = 30,
    atlas = "CustomBoosters",
    pos = { x = 9, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        rarity = 4,
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_titan_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}
