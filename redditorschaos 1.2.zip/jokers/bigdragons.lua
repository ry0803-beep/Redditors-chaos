SMODS.Joker{ --Big Dragons
    key = "bigdragons",
    config = {
        extra = {
            mult = 0,
            Xmult = 3
        }
    },
    loc_txt = {
        ['name'] = 'Big Dragons',
        ['text'] = {
            [1] = '{X:red,C:white}X3{} Mult if hand has at least',
            [2] = '{C:attention}3{} scoring',
            [3] = '{C:gold}Gold{}/{C:attention}Steel{}/Stone cards'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    cost = 6,
    rarity = "redditor_mahjong",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_gold"] == true then
            count = count + 1
        end
    end
    return count >= 3
end)() or (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_steel"] == true then
            count = count + 1
        end
    end
    return count >= 3
end)() or (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_stone"] == true then
            count = count + 1
        end
    end
    return count >= 3
end)()) then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}