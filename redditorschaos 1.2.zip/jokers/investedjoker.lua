SMODS.Joker{ --Invested Joker
    key = "investedjoker",
    config = {
        extra = {
            dollars = 5
        }
    },
    loc_txt = {
        ['name'] = 'Invested Joker',
        ['text'] = {
            [1] = '{C:money}$5{} per each {C:attention}#2#{} of {C:attention}#1#s{} is held in hand',
            [2] = 'at the end of the round',
            [3] = 'Card changes every round'
        }
    },
    pos = {
        x = 7,
        y = 3
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {localize((G.GAME.current_round.suitvar_card or {}).suit or 'Spades', 'suits_singular'), localize((G.GAME.current_round.rankvar_card or {}).rank or 'Ace', 'ranks')}, colours = {G.C.SUITS[(G.GAME.current_round.suitvar_card or {}).suit or 'Spades']}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.suitvar_card = { suit = 'Spades' }
        G.GAME.current_round.rankvar_card = { rank = 'Ace', id = 14 }
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
                if G.playing_cards then
                    local valid_suitvar_cards = {}
                    for _, v in ipairs(G.playing_cards) do
                        if not SMODS.has_no_suit(v) then
                            valid_suitvar_cards[#valid_suitvar_cards + 1] = v
                        end
                    end
                    if valid_suitvar_cards[1] then
                        local suitvar_card = pseudorandom_element(valid_suitvar_cards, pseudoseed('suitvar' .. G.GAME.round_resets.ante))
                        G.GAME.current_round.suitvar_card.suit = suitvar_card.base.suit
                    end
                end
                if G.playing_cards then
                        local valid_rankvar_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_rankvar_cards[#valid_rankvar_cards + 1] = v
                            end
                        end
                        if valid_rankvar_cards[1] then
                            local rankvar_card = pseudorandom_element(valid_rankvar_cards, pseudoseed('rankvar' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.rankvar_card.rank = rankvar_card.base.value
                            G.GAME.current_round.rankvar_card.id = rankvar_card.base.id
                        end
                    end
        end
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if (context.other_card:get_id() == G.GAME.current_round.rankvar_card.id and context.other_card:is_suit(G.GAME.current_round.suitvar_card.suit)) then
                return {
                    dollars = card.ability.extra.dollars
                }
            end
        end
    end
}