SMODS.Joker{ --Blue Card
    key = "bluecard",
    config = {
        extra = {
            multvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'Blue Card',
        ['text'] = {
            [1] = 'This Joker gains {C:mult}+3{} Mult when any {C:orange}Consumable{} is used',
            [2] = '{C:inactive}(Currently {C:red}+#1#{} {C:inactive}Mult){}{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.multvar}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.multvar
                }
        end
        if context.using_consumeable  then
                return {
                    func = function()
                    card.ability.extra.multvar = (card.ability.extra.multvar) + 3
                    return true
                end
                }
        end
    end
}