SMODS.Joker{ --Golden Ratio
    key = "goldenratio",
    config = {
        extra = {
            Xmult = 1.618
        }
    },
    loc_txt = {
        ['name'] = 'Golden Ratio',
        ['text'] = {
            [1] = 'Each played {C:attention}Ace{}, {C:attention}2{}, {C:attention}3{}, {C:attention}5{}, or {C:attention}8{}',
            [2] = 'gives {X:red,C:white}X1.618{} Mult when scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    cost = 13,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 2 or context.other_card:get_id() == 3 or context.other_card:get_id() == 14 or context.other_card:get_id() == 5 or context.other_card:get_id() == 8) then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}