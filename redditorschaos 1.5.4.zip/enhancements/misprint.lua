SMODS.Enhancement {
    key = 'misprint',
    pos = { x = 9, y = 0 },
    config = {
        extra = {
            mult_min = 1,
            mult_max = 23
        }
    },
    loc_txt = {
        name = 'Misprint',
        text = {
        [1] = 'Gain {C:red}+1 to {C:red}+23{} Mult{} when',
        [2] = 'this card is scored'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return { mult = pseudorandom('mult_eaf91cd3', card.ability.extra.mult_min, card.ability.extra.mult_max) }
        end
    end
}