SMODS.Joker{ --Sketched Joker
    key = "sketchedjoker",
    config = {
        extra = {
            card_draw = 1
        }
    },
    loc_txt = {
        ['name'] = 'Sketched Joker',
        ['text'] = {
            [1] = 'When you {C:red}discard{}, draw an extra {C:attention}card{}.'
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.pre_discard  then
                if G.GAME.blind.in_blind then
    SMODS.draw_cards(card.ability.extra.card_draw)
  end
                return {
                    message = "+"..tostring(card.ability.extra.card_draw).." Cards Drawn"
                }
        end
    end
}