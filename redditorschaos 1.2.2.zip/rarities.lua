SMODS.Rarity {
    key = "mahjong",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.01,
    badge_colour = HEX('6A7A8B'),
    loc_txt = {
        name = "Mahjong"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}