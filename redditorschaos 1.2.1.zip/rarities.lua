SMODS.Rarity {
    key = "mahjong",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.01,
    badge_colour = HEX('6A7A8B'),
    loc_txt = {
        name = "Mahjong"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "isaac",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.02,
    badge_colour = HEX('6A7A8B'),
    loc_txt = {
        name = "Isaac"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}