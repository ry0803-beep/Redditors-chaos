SMODS.Joker{ --Holy Mantle
    key = "holymantle",
    config = {
        extra = {
            hands = 1,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Holy Mantle',
        ['text'] = {
            [1] = 'When {C:attention}Boss Blind{} is selected',
            [2] = '{C:blue}+1{} hand for this round'
        }
    },
    pos = {
        x = 4,
        y = 3
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.setting_blind  then
            if G.GAME.blind.boss then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hands).." Hand", colour = G.C.GREEN})
                G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + card.ability.extra.hands
                return true
            end
                }
            end
        end
    end
}