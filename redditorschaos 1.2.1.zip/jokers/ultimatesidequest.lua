SMODS.Joker{ --Ultimate Sidequest
    key = "ultimatesidequest",
    config = {
        extra = {
            blind_size = 20,
            Spectral = 0
        }
    },
    loc_txt = {
        ['name'] = 'Ultimate Sidequest',
        ['text'] = {
            [1] = 'When you enter a {C:attention}Boss Blind{}',
            [2] = 'multiply blind requirement by {C:attention}20{}',
            [3] = 'When that {C:attention}Boss Blind{} is defeated',
            [4] = 'create a {C:dark_edition}Negative{} {C:spectral}Soul{} and {C:red}destroy{} this card'
        }
    },
    pos = {
        x = 6,
        y = 6
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.setting_blind  then
            if G.GAME.blind.boss then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "X"..tostring(card.ability.extra.blind_size).." Blind Size", colour = G.C.GREEN})
                G.GAME.blind.chips = G.GAME.blind.chips * card.ability.extra.blind_size
                G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                G.HUD_blind:recalculate()
                return true
            end
                }
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
                return {
                    func = function()local created_consumable = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.add_card{set = 'Spectral', key = 'c_soul', edition = 'e_negative', key_append = 'joker_forge_spectral'}
                        return true
                    end
                }))
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_spectral'), colour = G.C.SECONDARY_SET.Spectral})
                    end
                    return true
                end,
                    extra = {
                        func = function()
                card:start_dissolve()
                return true
            end,
                            message = "Completed",
                        colour = G.C.RED
                        }
                }
        end
    end
}