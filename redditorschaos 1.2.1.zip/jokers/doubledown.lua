SMODS.Joker{ --Double Down
    key = "doubledown",
    config = {
        extra = {
            mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Double Down',
        ['text'] = {
            [1] = 'This card gains {C:red}+3 Mult{} if {C:attention}Played hand{}',
            [2] = 'contains a {C:attention}Stone card{}',
            [3] = '{C:inactive}(currently{} {C:red}+#1#{} {C:inactive}Mult){}'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_stone"] == true then
            count = count + 1
        end
    end
    return count > 0
end)() then
                card.ability.extra.mult = (card.ability.extra.mult) + 3
            else
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}