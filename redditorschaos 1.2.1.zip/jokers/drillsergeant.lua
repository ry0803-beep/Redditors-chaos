SMODS.Joker{ --Drill Sergeant
    key = "drillsergeant",
    config = {
        extra = {
            dollars = 20
        }
    },
    loc_txt = {
        ['name'] = 'Drill Sergeant',
        ['text'] = {
            [1] = 'If {C:attention}First hand{} of round is',
            [2] = 'a single {C:attention}#1#{}, {C:red}Destroy{} it',
            [3] = 'and earn {C:money}$20{}',
            [4] = '{C:inactive}(rank changes every round){}'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {localize((G.GAME.current_round.jack_card or {}).rank or 'Ace', 'ranks')}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.jack_card = { rank = 'Ace', id = 14 }
    end,

    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if (context.other_card:get_id() == G.GAME.current_round.jack_card.id and G.GAME.current_round.hands_played == 0) then
                context.other_card.should_destroy = true
                return {
                    dollars = card.ability.extra.dollars,
                    extra = {
                        message = "Destroyed!",
                        colour = G.C.RED
                        }
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                if G.playing_cards then
                        local valid_jack_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_jack_cards[#valid_jack_cards + 1] = v
                            end
                        end
                        if valid_jack_cards[1] then
                            local jack_card = pseudorandom_element(valid_jack_cards, pseudoseed('jack' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.jack_card.rank = jack_card.base.value
                            G.GAME.current_round.jack_card.id = jack_card.base.id
                        end
                    end
        end
    end
}