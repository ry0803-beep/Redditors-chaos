SMODS.Joker{ --Gamblers Number
    key = "gamblersnumber",
    config = {
        extra = {
            Tarot = 0
        }
    },
    loc_txt = {
        ['name'] = 'Gamblers Number',
        ['text'] = {
            [1] = 'When you play a hand with exactly {C:attention}3{} scored {C:attention}7{}s',
            [2] = 'create a {C:dark_edition}Negative{} {C:tarot}Wheel of fortune{}'
        }
    },
    pos = {
        x = 4,
        y = 3
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 7 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount == 3
end)() then
                local created_consumable = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.add_card{set = 'Tarot', key = 'c_wheel_of_fortune', edition = 'e_negative', key_append = 'joker_forge_tarot'}
                        return true
                    end
                }))
                return {
                    message = created_consumable and localize('k_plus_tarot') or nil
                }
            end
        end
    end
}