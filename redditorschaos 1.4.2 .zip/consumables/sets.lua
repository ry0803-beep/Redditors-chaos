SMODS.ConsumableType {
    key = 'soul',
    primary_colour = HEX('666666'),
    secondary_colour = HEX('666666'),
    collection_rows = { 4, 5 },
    shop_rate = 0,
    cards = {
        ['c_redditor_thesoul2'] = true
    },
    loc_txt = {
        name = "soul",
        collection = "soul Cards",
    }
}