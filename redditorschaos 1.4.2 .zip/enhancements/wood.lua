SMODS.Enhancement {
    key = 'wood',
    pos = { x = 3, y = 0 },
    config = {
        mult = 15
    },
    loc_txt = {
        name = 'Wood',
        text = {
        [1] = '{C:red}+15 Mult{} this card always scores',
        [2] = 'this card has no rank or suit'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = true,
    no_suit = true,
    always_scores = true,
    unlocked = true,
    discovered = true,
    no_collection = false
}