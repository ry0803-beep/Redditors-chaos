SMODS.Rarity {
    key = "mahjong",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.01,
    badge_colour = HEX('6A7A8B'),
    loc_txt = {
        name = "Mahjong"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "pepsi",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('0019ff'),
    loc_txt = {
        name = "Pepsi"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "fusion",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('8b6a77'),
    loc_txt = {
        name = "fusion"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}