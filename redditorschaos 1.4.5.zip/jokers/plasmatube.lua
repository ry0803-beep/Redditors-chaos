SMODS.Joker{ --Plasma Tube
    key = "plasmatube",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Plasma Tube',
        ['text'] = {
            [1] = 'Balance {C:blue}Chips{} and {C:red}Mult{}'
        }
    },
    pos = {
        x = 0,
        y = 7
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    balance = true
                }
        end
    end
}