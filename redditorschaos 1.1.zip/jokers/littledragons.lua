SMODS.Joker{ --Little Dragons
    key = "littledragons",
    config = {
        extra = {
            mult = 0,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Little Dragons',
        ['text'] = {
            [1] = 'This card Gains {C:red}+5 Mult{}',
            [2] = 'per hand with at least 2 scoring',
            [3] = '{C:gold}Gold{}/{C:attention}Steel{}/Stone cards',
            [4] = '{C:inactive}(currently{} {C:red}+#1#{} {C:inactive}Mult){}'
        }
    },
    pos = {
        x = 3,
        y = 3
    },
    cost = 5,
    rarity = "redditor_mahjong",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_gold"] == true then
            count = count + 1
        end
    end
    return count >= 2
end)() or (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_steel"] == true then
            count = count + 1
        end
    end
    return count >= 2
end)() or (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_stone"] == true then
            count = count + 1
        end
    end
    return count >= 2
end)()) then
                card.ability.extra.var1 = (card.ability.extra.var1) + 5
            else
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}