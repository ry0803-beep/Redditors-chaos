SMODS.Joker{ --Four Concealed Triplets
    key = "fourconcealedtriplets",
    config = {
        extra = {
            mult = 0,
            Xmult = 4
        }
    },
    loc_txt = {
        ['name'] = 'Four Concealed Triplets',
        ['text'] = {
            [1] = '{X:red,C:white}X4{} Mult every {C:attention}4{} hands played',
            [2] = 'containing a{C:attention} Three of a kind{}',
            [3] = 'resets on {C:red}Discard{}',
            [4] = '{C:inactive}(currently{} {C:attention}#1#{}{C:inactive}/4){}'
        }
    },
    pos = {
        x = 2,
        y = 2
    },
    cost = 6,
    rarity = "redditor_mahjong",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if next(context.poker_hands["Three of a Kind"]) then
                card.ability.extra.mult = (card.ability.extra.mult) + 1
            elseif (card.ability.extra.mult or 0) == 4 then
                card.ability.extra.mult = 0
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
        if context.pre_discard  then
                return {
                    func = function()
                    card.ability.extra.mult = 0
                    return true
                end
                }
        end
    end
}