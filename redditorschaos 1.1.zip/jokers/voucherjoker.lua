SMODS.Joker{ --Voucher Joker
    key = "voucherjoker",
    config = {
        extra = {
            voucher_slots = 1
        }
    },
    loc_txt = {
        ['name'] = 'Voucher Joker',
        ['text'] = {
            [1] = '{C:attention}+1{} Voucher slot'
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.selling_self  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.voucher_slots).." Voucher Slots", colour = G.C.RED})
                SMODS.change_voucher_limit(-card.ability.extra.voucher_slots)
                return true
            end
                }
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        SMODS.change_voucher_limit(1)
    end,

    remove_from_deck = function(self, card, from_debuff)
        SMODS.change_voucher_limit(-1)
    end
}