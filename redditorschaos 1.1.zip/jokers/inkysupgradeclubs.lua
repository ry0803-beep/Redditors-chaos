SMODS.Joker{ --Inkys Upgrade Clubs
    key = "inkysupgradeclubs",
    config = {
        extra = {
            levels = 1
        }
    },
    loc_txt = {
        ['name'] = 'Inkys Upgrade Clubs',
        ['text'] = {
            [1] = 'When a {C:clubs}Club{} is scored, {C:attention}Upgrade{}',
            [2] = 'A random Hand'
        }
    },
    pos = {
        x = 8,
        y = 2
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Clubs") then
                available_hands = {}
        for hand, value in pairs(G.GAME.hands) do
          if value.visible and value.level >= 1 then
            table.insert(available_hands, hand)
          end
        end
        target_hand = #available_hands > 0 and pseudorandom_element(available_hands, pseudoseed('level_up_hand')) or "High Card"
                return {
                    level_up = card.ability.extra.levels,
      level_up_hand = target_hand,
                    message = localize('k_level_up_ex')
                }
            end
        end
    end
}