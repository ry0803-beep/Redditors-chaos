SMODS.Joker{ --Chaos Choas
    key = "chaoschoas",
    config = {
        extra = {
            chips_min = -100,
            chips_max = 100,
            mult_min = -100,
            mult_max = 100,
            xchips_min = 0.1,
            xchips_max = 3,
            Xmult_min = 0.1,
            Xmult_max = 3
        }
    },
    loc_txt = {
        ['name'] = 'Chaos Choas',
        ['text'] = {
            [1] = 'Gain between {X:blue,C:white}X0.1{} Chips to {X:blue,C:white}X3{} Chips',
            [2] = '{X:red,C:white}X0.1{} Mult to {X:red,C:white}X3{} Mult',
            [3] = '{C:red}-100{} Mult to {C:red}+100{} Mult',
            [4] = '{C:blue}-100 {}Chips to {C:blue}+100{} Chips'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = pseudorandom('chips_272073f9', card.ability.extra.chips_min, card.ability.extra.chips_max),
                    extra = {
                        mult = pseudorandom('mult_b2905d2a', card.ability.extra.mult_min, card.ability.extra.mult_max),
                        extra = {
                            x_chips = pseudorandom('xchips_c9671761', card.ability.extra.xchips_min, card.ability.extra.xchips_max),
                            colour = G.C.DARK_EDITION,
                        extra = {
                            Xmult = pseudorandom('Xmult_69e9a247', card.ability.extra.Xmult_min, card.ability.extra.Xmult_max)
                        }
                        }
                        }
                }
        end
    end
}