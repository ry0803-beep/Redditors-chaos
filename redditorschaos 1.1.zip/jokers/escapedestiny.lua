SMODS.Joker{ --Escape Destiny
    key = "escapedestiny",
    config = {
        extra = {
            Tarot = 0
        }
    },
    loc_txt = {
        ['name'] = 'Escape Destiny',
        ['text'] = {
            [1] = 'If {C:attention}First hand{} of round wins the round,',
            [2] = 'gain a {C:dark_edition}Negative{} {C:tarot}tarot{} {C:attention}card{}'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (G.GAME.current_round.hands_played == 0 and G.GAME.chips / G.GAME.blind.chips >= to_big(1)) then
                local created_consumable = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.add_card{set = 'Tarot', key = nil, edition = 'e_negative', key_append = 'joker_forge_tarot'}
                        return true
                    end
                }))
                return {
                    message = created_consumable and localize('k_plus_tarot') or nil
                }
            end
        end
    end
}