SMODS.Joker{ --Racist Chud
    key = "racistchud",
    config = {
        extra = {
            Xmult = 0.5,
            mult = 14
        }
    },
    loc_txt = {
        ['name'] = 'Racist Chud',
        ['text'] = {
            [1] = '{C:red}+14 Mult{} but {X:red,C:white}X0.5{} Mult',
            [2] = 'if your {C:attention}Played hand{}',
            [3] = 'contains a {C:spades}Spade{} card'
        }
    },
    pos = {
        x = 5,
        y = 6
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local suitFound = false
    for i, c in ipairs(context.scoring_hand) do
        if c:is_suit("Spades") then
            suitFound = true
            break
        end
    end
    
    return suitFound
end)() then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            else
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}