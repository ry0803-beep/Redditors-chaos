SMODS.Joker{ --Original Copy
    key = "originalcopy",
    config = {
        extra = {
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "2",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "3",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "4",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "5",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "6",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "7",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "8",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "9",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "10"
        }
    },
    loc_txt = {
        ['name'] = 'Original Copy',
        ['text'] = {
            [1] = '{C:attention}Aces{} now count as all {C:attention}Numbered cards{}'
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    add_to_deck = function(self, card, from_debuff)
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
    end,

    remove_from_deck = function(self, card, from_debuff)
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
    end
}


local card_get_id_ref = Card.get_id
function Card:get_id()
    local original_id = card_get_id_ref(self)
    if not original_id then return original_id end

    if next(SMODS.find_card("j_redditor_originalcopy")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 2 end
        end
    end
    if next(SMODS.find_card("j_redditor_originalcopy")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 3 end
        end
    end
    if next(SMODS.find_card("j_redditor_originalcopy")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 4 end
        end
    end
    if next(SMODS.find_card("j_redditor_originalcopy")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 5 end
        end
    end
    if next(SMODS.find_card("j_redditor_originalcopy")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 6 end
        end
    end
    if next(SMODS.find_card("j_redditor_originalcopy")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 7 end
        end
    end
    if next(SMODS.find_card("j_redditor_originalcopy")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 8 end
        end
    end
    if next(SMODS.find_card("j_redditor_originalcopy")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 9 end
        end
    end
    if next(SMODS.find_card("j_redditor_originalcopy")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 10 end
        end
    end
    return original_id
end
