SMODS.Enhancement {
    key = 'draw4',
    pos = { x = 7, y = 0 },
    config = {
        extra = {
            odds = 4
        }
    },
    loc_txt = {
        name = 'Draw 4',
        text = {
        [1] = 'When this card is held in hand',
        [2] = '{C:green}#1# in #2#{} chance to draw {C:attention}4{} cards'
    }
    },
    atlas = 'CustomEnhancements',
    pos = { x = 0, y = 0 },
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'm_redditor_draw4')
        return {vars = {numerator, denominator}}
    end,
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.other_card == card then
        end
    end
}