SMODS.Joker{ --Common Ends
    key = "commonends",
    config = {
        extra = {
            mult = 0,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Common Ends',
        ['text'] = {
            [1] = 'This card gains {C:red}+2 Mult{}',
            [2] = 'for every hand played',
            [3] = 'with a scoring {C:attention}Face card{} or {C:attention}Ace{}',
            [4] = '{C:inactive}(currently{} {C:red}+#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 2
    },
    cost = 5,
    rarity = "redditor_mahjong",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:is_face() then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)() or (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 14 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)()) then
                card.ability.extra.var1 = (card.ability.extra.var1) + 2
            else
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}