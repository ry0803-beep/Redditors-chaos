SMODS.Joker{ --Krisgendering
    key = "krisgendering",
    config = {
        extra = {
            xmult = 4.8
        }
    },
    loc_txt = {
        ['name'] = 'Krisgendering',
        ['text'] = {
            [1] = 'For each citation of kris\'s gender',
            [2] = 'this card gains {X:red,C:white}X0.1{} Mult',
            [3] = '{C:inactive}(currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 7
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.xmult
                }
        end
    end
}