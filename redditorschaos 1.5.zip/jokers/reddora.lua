SMODS.Joker{ --Red Dora
    key = "reddora",
    config = {
        extra = {
            mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Red Dora',
        ['text'] = {
            [1] = 'This card gains {C:red}+4 Mult{} for each',
            [2] = '5 of {C:diamonds}Diamonds{} or {C:hearts}Hearts{} played',
            [3] = '{C:inactive}(currently{} {C:red}+#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 9
    },
    cost = 5,
    rarity = "redditor_mahjong",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 5 and context.other_card:is_suit("Hearts") or context.other_card:is_suit("Diamonds")) then
                card.ability.extra.mult = (card.ability.extra.mult) + 4
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.mult
                }
        end
    end
}