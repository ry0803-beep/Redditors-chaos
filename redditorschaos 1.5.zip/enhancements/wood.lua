SMODS.Enhancement {
    key = 'wood',
    pos = { x = 9, y = 0 },
    config = {
        mult = 15
    },
    loc_txt = {
        name = 'Wood',
        text = {
        [1] = '{C:red}+15 Mult{} always scores has no rank or suit'
    }
    },
    atlas = 'CustomEnhancements',
    pos = { x = 0, y = 0 },
    any_suit = false,
    replace_base_card = true,
    no_rank = true,
    no_suit = true,
    always_scores = true,
    unlocked = true,
    discovered = true,
    no_collection = false
}