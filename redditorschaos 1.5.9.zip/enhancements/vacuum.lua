SMODS.Enhancement {
    key = 'vacuum',
    pos = { x = 4, y = 2 },
    loc_txt = {
        name = 'Vacuum',
        text = {
        [1] = '{C:attention}Retrigger{} this card {C:attention}2{} times',
        [2] = 'this card has no rank or suit',
        [3] = 'this card always scores'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = true,
    no_rank = true,
    no_suit = true,
    always_scores = true,
    unlocked = true,
    discovered = true,
    no_collection = false
}