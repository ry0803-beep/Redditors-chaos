SMODS.Enhancement {
    key = 'gammarayburst',
    pos = { x = 2, y = 1 },
    config = {
        extra = {
            levels = 1
        }
    },
    loc_txt = {
        name = 'Gamma Ray Burst',
        text = {
        [1] = 'When this card is Held in hand',
        [2] = 'at the end of round upgrade',
        [3] = '{C:attention}Played Hand{} by {C:attention}1{}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.end_of_round and context.cardarea == G.hand and context.other_card == card and context.individual then
            local target_hand
                target_hand = context.scoring_name or "High Card"
            SMODS.calculate_effect({level_up = card.ability.extra.levels,
                level_up_hand = target_hand}, card)
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_level_up_ex'), colour = G.C.RED})
        end
    end
}