SMODS.Enhancement {
    key = 'knight',
    pos = { x = 4, y = 1 },
    config = {
        extra = {
            x_mult = 3
        }
    },
    loc_txt = {
        name = 'Knight',
        text = {
        [1] = '{X:red,C:white}X3{} Mult when held in hand',
        [2] = 'if you have {C:attention}Emperor Joker{}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.main_scoring and (function()
    for i = 1, #G.jokers.cards do
        if G.jokers.cards[i].config.center.key == "j_redditor_emperorjoker" then
            return true
        end
    end
    return false
end)() then
            return { x_mult = card.ability.extra.x_mult }
        end
    end
}