SMODS.Seal {
    key = 'greenseal',
    pos = { x = 3, y = 0 },
    config = {
        extra = {
            handsremaining = 0
        }
    },
    badge_colour = HEX('32CD32'),
   loc_txt = {
        name = 'Green Seal',
        label = 'Green Seal',
        text = {
        [1] = 'Gain money based on {C:blue}hands{} remaining',
        [2] = 'when this card is held in hand',
        [3] = '{C:inactive}(currently {}{C:money}$#1#{}{C:inactive}){}'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        return {vars = {(G.GAME.current_round.hands_left or 0)}}
    end,
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.main_scoring then
            return { dollars = lenient_bignum(G.GAME.current_round.hands_left) }
        end
    end
}