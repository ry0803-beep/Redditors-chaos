SMODS.Joker{ --labubu
    key = "labubu",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'labubu',
        ['text'] = {
            [1] = 'does nothing'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 8
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers'
}