SMODS.Joker{ --Vacuum Cleaner
    key = "vacuumcleaner",
    config = {
        extra = {
            handsleft = 4
        }
    },
    loc_txt = {
        ['name'] = 'Vacuum Cleaner',
        ['text'] = {
            [1] = 'You can {C:red}discard{} an infinite amount of card',
            [2] = 'When you {C:red}discard{} {C:attention}5{} times this card {C:red}destroys{} itself'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 14
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.pre_discard  then
            if (card.ability.extra.handsleft or 0) == 0 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Destroyed!"
                }
            else
                return {
                    func = function()
                    card.ability.extra.handsleft = math.max(0, (card.ability.extra.handsleft) - 1)
                    return true
                end
                }
            end
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        SMODS.change_discard_limit(1000000)
    end,

    remove_from_deck = function(self, card, from_debuff)
        SMODS.change_discard_limit(-1000000)
    end
}