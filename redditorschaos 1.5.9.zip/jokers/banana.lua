SMODS.Joker{ --Banana²
    key = "banana",
    config = {
        extra = {
            odds = 6,
            repetitions = 1
        }
    },
    loc_txt = {
        ['name'] = 'Banana²',
        ['text'] = {
            [1] = '{C:attention}Retrigger{} all banana cards',
            [2] = '{C:green}#1# in #2#{} this card destroys itself',
            [3] = 'at the end of round'
        },
        ['unlock'] = {
            [1] = 'Have 20 Banana cards in your deck'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_redditor_banana') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_c0e2fe06', 1, card.ability.extra.odds, 'j_redditor_banana') then
                      SMODS.calculate_effect({func = function()
                card:start_dissolve()
                return true
            end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Gone", colour = G.C.RED})
                  end
            end
        end
        if context.repetition and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_redditor_banana"] == true then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            end
        end
    end,
  check_for_unlock = function(self,args)
    if args.type == "modify_deck" then
      local count = 0
        for _, card in ipairs(G.playing_cards or {}) do
    if SMODS.has_enhancement(card, "") then
      count = count + 1
    end
    end
      if count >= to_big(20) then
        return true
      end
  end
  return false
  end
}