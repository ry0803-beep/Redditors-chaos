SMODS.Joker{ --Infinity Sided Die
    key = "infinitysideddie",
    config = {
        extra = {
            set_probability = 1,
            both = 0
        }
    },
    loc_txt = {
        ['name'] = 'Infinity Sided Die',
        ['text'] = {
            [1] = 'All {C:attention}listed{} probability\'s are {C:green}guaranteed{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 7
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.fix_probability  then
        local numerator, denominator = context.numerator, context.denominator
                numerator = card.ability.extra.set_probability
        denominator = card.ability.extra.set_probability
      return {
        numerator = numerator, 
        denominator = denominator
      }
        end
    end
}