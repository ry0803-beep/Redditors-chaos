SMODS.Joker{ --Flower Bouquet
    key = "flowerbouquet",
    config = {
        extra = {
            triggered = 0,
            pb_x_mult_cf61d1ee = 0.2,
            perma_x_mult = 0,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Flower Bouquet',
        ['text'] = {
            [1] = 'If hand is a {C:attention}Flush{} of {C:hearts}Hearts{}',
            [2] = 'Convert them all to {C:spades}Spades{}',
            [3] = 'And they Permanently Gain {X:red,C:white}X0.2{} Mult',
            [4] = 'Then {C:red}Destroy{} this card'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 5
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.scoring_name == "Flush" and (function()
    local allMatchSuit = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:is_suit("Hearts")) then
            allMatchSuit = false
            break
        end
    end
    
    return allMatchSuit and #context.scoring_hand > 0
end)()) then
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult or 0
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult + card.ability.extra.pb_x_mult_cf61d1ee
                assert(SMODS.change_base(context.other_card, "Spades", nil))
                card.ability.extra.triggered = 1
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.MULT }, card = card,
                    extra = {
                        message = "Card Modified!",
                        colour = G.C.BLUE
                        }
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
            if (card.ability.extra.triggered or 0) == 1 then
                return {
                    func = function()
                local destructable_jokers = {}
                for i, joker in ipairs(G.jokers.cards) do
                    if joker ~= card and not joker.ability.eternal and not joker.getting_sliced then
                        table.insert(destructable_jokers, joker)
                    end
                end
                local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker')) or nil
                
                if target_joker then
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                end
                    return true
                end
                }
            end
        end
    end
}