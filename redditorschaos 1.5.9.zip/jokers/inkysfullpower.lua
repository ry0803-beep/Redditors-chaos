SMODS.Joker{ --Inkys Full Power
    key = "inkysfullpower",
    config = {
        extra = {
            upgrade = 3
        }
    },
    loc_txt = {
        ['name'] = 'Inkys Full Power',
        ['text'] = {
            [1] = 'If a {C:attention}Scoring{} {C:clubs}Club{} is in the {C:attention}Played hand{}',
            [2] = 'upgrade {C:attention}Played hand{} by {C:attention}#1#{}',
            [3] = 'When a {C:attention}Ace{}, {C:attention}2{}, {C:attention}3{}, {C:attention}5{}, or {C:attention}8{} is {C:attention}scored{}',
            [4] = 'Increase the upgrade effect by {C:attention}1{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 7
    },
    cost = 5,
    rarity = "redditor_fusion",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',

    in_pool = function(self, args)
        return args.source ~= 'sho'
    end,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.upgrade}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local suitCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:is_suit("Clubs") then
            suitCount = suitCount + 1
        end
    end
    
    return suitCount >= 1
end)() then
                target_hand = context.scoring_name
                return {
                    level_up = card.ability.extra.upgrade,
      level_up_hand = target_hand,
                    message = localize('k_level_up_ex')
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 2 or context.other_card:get_id() == 3 or context.other_card:get_id() == 5 or context.other_card:get_id() == 8 or context.other_card:get_id() == 14) then
                card.ability.extra.upgrade = (card.ability.extra.upgrade) + 1
                return {
                    message = "Fibonacci"
                }
            end
        end
    end
}