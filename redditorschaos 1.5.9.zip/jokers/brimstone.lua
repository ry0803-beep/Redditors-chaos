SMODS.Joker{ --Brimstone
    key = "brimstone",
    config = {
        extra = {
            handsleft = 1,
            Xmult = 2
        }
    },
    loc_txt = {
        ['name'] = 'Brimstone',
        ['text'] = {
            [1] = '{X:red,C:white}X2{} Mult every {C:attention}2{} hands played',
            [2] = '{C:inactive}({C:attention}#1#{} {C:inactive}hands Left){}{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    cost = 5,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.handsleft}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (card.ability.extra.handsleft or 0) <= 0 then
                card.ability.extra.handsleft = 1
                return {
                    Xmult = card.ability.extra.Xmult
                }
            else
                card.ability.extra.handsleft = math.max(0, (card.ability.extra.handsleft) - 1)
            end
        end
    end
}