SMODS.Joker{ --Void
    key = "void",
    config = {
        extra = {
            chips = 100,
            mult = 100
        }
    },
    loc_txt = {
        ['name'] = 'Void',
        ['text'] = {
            [1] = 'If {C:attention} Played hand{} contains {C:attention}0{} cards',
            [2] = '{C:blue}+100 Chips{} and {C:red}+100 Mult{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 15
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if #context.full_hand == 0 then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        mult = card.ability.extra.mult
                        }
                }
            end
        end
    end
}