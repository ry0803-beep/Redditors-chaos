SMODS.Joker{ --Equality
    key = "equality",
    config = {
        extra = {
            source_rank_type = "all",
            target_rank = "2",
            source_rank_type = "all",
            target_rank = "3",
            source_rank_type = "all",
            target_rank = "4",
            source_rank_type = "all",
            target_rank = "5",
            source_rank_type = "all",
            target_rank = "6",
            source_rank_type = "all",
            target_rank = "7",
            source_rank_type = "all",
            target_rank = "8",
            source_rank_type = "all",
            target_rank = "9",
            source_rank_type = "all",
            target_rank = "10",
            source_rank_type = "all",
            target_rank = "J",
            source_rank_type = "all",
            target_rank = "Q",
            source_rank_type = "all",
            target_rank = "K",
            source_rank_type = "all",
            target_rank = "A"
        }
    },
    loc_txt = {
        ['name'] = 'Equality',
        ['text'] = {
            [1] = 'All {C:attention}cards{} count as all {C:attention}suits{} and {C:attention}ranks{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 5
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
    end,

    add_to_deck = function(self, card, from_debuff)
        -- Combine suits effect enabled
        -- Combine suits effect enabled
        -- Combine suits effect enabled
        -- Combine suits effect enabled
        -- Combine suits effect enabled
        -- Combine suits effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
    end,

    remove_from_deck = function(self, card, from_debuff)
        -- Combine suits effect disabled
        -- Combine suits effect disabled
        -- Combine suits effect disabled
        -- Combine suits effect disabled
        -- Combine suits effect disabled
        -- Combine suits effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
    end
}


local card_get_id_ref = Card.get_id
function Card:get_id()
    local original_id = card_get_id_ref(self)
    if not original_id then return original_id end

    if next(SMODS.find_card("j_redditor_equality")) then
        return 2
    end
    if next(SMODS.find_card("j_redditor_equality")) then
        return 3
    end
    if next(SMODS.find_card("j_redditor_equality")) then
        return 4
    end
    if next(SMODS.find_card("j_redditor_equality")) then
        return 5
    end
    if next(SMODS.find_card("j_redditor_equality")) then
        return 6
    end
    if next(SMODS.find_card("j_redditor_equality")) then
        return 7
    end
    if next(SMODS.find_card("j_redditor_equality")) then
        return 8
    end
    if next(SMODS.find_card("j_redditor_equality")) then
        return 9
    end
    if next(SMODS.find_card("j_redditor_equality")) then
        return 10
    end
    if next(SMODS.find_card("j_redditor_equality")) then
        return 11
    end
    if next(SMODS.find_card("j_redditor_equality")) then
        return 12
    end
    if next(SMODS.find_card("j_redditor_equality")) then
        return 13
    end
    if next(SMODS.find_card("j_redditor_equality")) then
        return 14
    end
    return original_id
end

local card_is_suit_ref = Card.is_suit
function Card:is_suit(suit, bypass_debuff, flush_calc)
    local ret = card_is_suit_ref(self, suit, bypass_debuff, flush_calc)
    if not ret and not SMODS.has_no_suit(self) then
        if next(SMODS.find_card("j_redditor_equality")) then
            -- If checking for Spades and card is Hearts, return true
            if suit == "Spades" and self.base.suit == "Hearts" then
                ret = true
            end
            -- If checking for Hearts and card is Spades, return true
            if suit == "Hearts" and self.base.suit == "Spades" then
                ret = true
            end
            -- If checking for Spades and card is Diamonds, return true
            if suit == "Spades" and self.base.suit == "Diamonds" then
                ret = true
            end
            -- If checking for Diamonds and card is Spades, return true
            if suit == "Diamonds" and self.base.suit == "Spades" then
                ret = true
            end
            -- If checking for Spades and card is Clubs, return true
            if suit == "Spades" and self.base.suit == "Clubs" then
                ret = true
            end
            -- If checking for Clubs and card is Spades, return true
            if suit == "Clubs" and self.base.suit == "Spades" then
                ret = true
            end
            -- If checking for Hearts and card is Diamonds, return true
            if suit == "Hearts" and self.base.suit == "Diamonds" then
                ret = true
            end
            -- If checking for Diamonds and card is Hearts, return true
            if suit == "Diamonds" and self.base.suit == "Hearts" then
                ret = true
            end
            -- If checking for Hearts and card is Clubs, return true
            if suit == "Hearts" and self.base.suit == "Clubs" then
                ret = true
            end
            -- If checking for Clubs and card is Hearts, return true
            if suit == "Clubs" and self.base.suit == "Hearts" then
                ret = true
            end
            -- If checking for Diamonds and card is Clubs, return true
            if suit == "Diamonds" and self.base.suit == "Clubs" then
                ret = true
            end
            -- If checking for Clubs and card is Diamonds, return true
            if suit == "Clubs" and self.base.suit == "Diamonds" then
                ret = true
            end
        end
    end
    return ret
end