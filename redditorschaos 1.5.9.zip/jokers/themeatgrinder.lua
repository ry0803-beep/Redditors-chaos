SMODS.Joker{ --The Meatgrinder
    key = "themeatgrinder",
    config = {
        extra = {
            mult = 20
        }
    },
    loc_txt = {
        ['name'] = 'The Meatgrinder',
        ['text'] = {
            [1] = '{C:red}+20 Mult{} if {C:attention}Played hand{}',
            [2] = 'contains a {C:attention}Flush{} and a {C:attention}Pair{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 14
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (next(context.poker_hands["Flush"]) and next(context.poker_hands["Pair"])) then
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}