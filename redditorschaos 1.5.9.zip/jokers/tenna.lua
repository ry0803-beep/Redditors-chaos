SMODS.Joker{ --Tenna
    key = "tenna",
    config = {
        extra = {
            odds = 7
        }
    },
    loc_txt = {
        ['name'] = 'Tenna',
        ['text'] = {
            [1] = '{C:green}#1# in #2#{} chance to change a cards {C:attention}rank{}',
            [2] = 'into {C:attention}10{} and make it an {C:attention}An10na{} card',
            [3] = 'when a card is scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 13
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_redditor_tenna') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_2713a38c', 1, card.ability.extra.odds, 'j_redditor_tenna') then
                      assert(SMODS.change_base(context.other_card, nil, "10"))
                context.other_card:set_ability(G.P_CENTERS.m_redditor_an10na)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
                  end
            end
        end
    end
}