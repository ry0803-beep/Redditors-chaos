SMODS.Joker{ --Spamton Neo
    key = "spamtonneo",
    config = {
        extra = {
            odds = 7
        }
    },
    loc_txt = {
        ['name'] = 'Spamton Neo',
        ['text'] = {
            [1] = '{C:green}#1# in #2#{} chance to make a {C:attention}scored{}',
            [2] = 'card a {C:attention}NEO{} card'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 13
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_redditor_spamtonneo') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_ad006652', 1, card.ability.extra.odds, 'j_redditor_spamtonneo') then
                      context.other_card:set_ability(G.P_CENTERS.m_redditor_neo)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
                  end
            end
        end
    end
}