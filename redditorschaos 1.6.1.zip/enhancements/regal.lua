SMODS.Enhancement {
    key = 'regal',
    pos = { x = 9, y = 1 },
    config = {
        mult = -20,
        bonus = 200
    },
    loc_txt = {
        name = 'Regal',
        text = {
        [1] = '{C:blue}+200 Chips{}',
        [2] = '{C:red}-20 Mult{}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false
}