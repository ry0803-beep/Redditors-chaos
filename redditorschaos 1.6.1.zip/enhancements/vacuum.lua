SMODS.Enhancement {
    key = 'vacuum',
    pos = { x = 4, y = 2 },
    config = {
        bonus = 10,
        extra = {
            retrigger_times = 2
        }
    },
    loc_txt = {
        name = 'Vacuum',
        text = {
        [1] = '{C:blue}+10{} Chips',
        [2] = '{C:attention}Retrigger{} this card {C:attention}2{} times',
        [3] = 'this card has no rank or suit',
        [4] = 'this card always scores'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = true,
    no_rank = true,
    no_suit = true,
    always_scores = true,
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.repetition and card.should_retrigger then
            return { repetitions = card.ability.extra.retrigger_times }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_retrigger = false
            card.should_retrigger = true
            card.ability.extra.retrigger_times = 2
        end
    end
}