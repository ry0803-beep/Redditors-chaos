SMODS.Joker{ --All Green
    key = "allgreen",
    config = {
        extra = {
            xmult = 1,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'All Green',
        ['text'] = {
            [1] = 'This card gains {X:red,C:white}X1{} Mult',
            [2] = 'Per Consecutive {C:clubs}Club{} {C:attention}Flush{} played',
            [3] = '{C:inactive}(currently at{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    cost = 6,
    rarity = "redditor_mahjong",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return not args or args.source ~= 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
      end
    ,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (context.scoring_name == "Flush" and (function()
    local allMatchSuit = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:is_suit("Clubs")) then
            allMatchSuit = false
            break
        end
    end
    
    return allMatchSuit and #context.scoring_hand > 0
end)()) then
                card.ability.extra.var1 = (card.ability.extra.var1) + 1
            elseif (not (context.scoring_name ~= "Flush") or not ((function()
    local allMatchSuit = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:is_suit("Clubs")) then
            allMatchSuit = false
            break
        end
    end
    
    return allMatchSuit and #context.scoring_hand > 0
end)())) then
                card.ability.extra.xmult = 1
            else
                return {
                    Xmult = card.ability.extra.xmult
                }
            end
        end
    end
}