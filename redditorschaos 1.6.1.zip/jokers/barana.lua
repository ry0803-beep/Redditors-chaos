SMODS.Joker{ --Barana
    key = "barana",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Barana',
        ['text'] = {
            [1] = 'Each {C:orange}Banana{} card held in hand',
            [2] = 'Creates a {C:attention}Banana{} card with the',
            [3] = '{C:attention}King{} Rank'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return not args or args.source ~= 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
      end
    ,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_redditor_banana"] == true then
                local card_front = pseudorandom_element({G.P_CARDS.S_K, G.P_CARDS.H_K, G.P_CARDS.D_K, G.P_CARDS.C_K}, pseudoseed('add_card_suit'))
                local base_card = create_playing_card({
                    front = card_front,
                    center = G.P_CENTERS.m_redditor_banana
                }, G.discard, true, false, nil, true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                local new_card = copy_card(base_card, nil, nil, G.playing_card)
                new_card:add_to_deck()
                G.deck.config.card_limit = G.deck.config.card_limit + 1
                G.deck:emplace(new_card)
                table.insert(G.playing_cards, new_card)
                
                base_card:remove()
                
                G.E_MANAGER:add_event(Event({
                    func = function() 
                        new_card:start_materialize()
                        return true
                    end
                }))
                return {
                    message = "Added Card!"
                }
            end
        end
    end
}