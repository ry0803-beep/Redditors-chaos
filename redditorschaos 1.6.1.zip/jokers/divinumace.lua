SMODS.Joker{ --Divinum Ace
    key = "divinumace",
    config = {
        extra = {
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "2",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "3",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "4",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "5",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "6",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "7",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "8",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "9",
            source_rank_type = "specific",
            source_ranks = {"A"},
            target_rank = "10",
            xmult1 = 1,
            mult = 0,
            chips = 0,
            xmult2 = 1,
            repetitions = 2,
            mult2 = 4,
            chips2 = 20,
            odds = 10,
            Tarot = 0
        }
    },
    loc_txt = {
        ['name'] = 'Divinum Ace',
        ['text'] = {
            [1] = 'has the effects of every {C:attention}Ace{} related joker',
            [2] = '{C:inactive}(including ones from this mod){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return not args or args.source ~= 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
      end
    ,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 14 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)() and next(context.poker_hands["Straight"])) then
                local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Tarot', key = nil, key_append = 'joker_forge_tarot'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                return {
                    message = created_consumable and localize('k_plus_tarot') or nil
                }
            elseif ((function()
    local allMatchRank = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:is_face()) then
            allMatchRank = false
            break
        end
    end
    
    return allMatchRank and #context.scoring_hand > 0
end)() or (function()
    local allMatchRank = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:get_id() == 14) then
            allMatchRank = false
            break
        end
    end
    
    return allMatchRank and #context.scoring_hand > 0
end)()) then
                card.ability.extra.xmult1 = (card.ability.extra.xmult1) + 0.2
            elseif ((function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 14 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)() or (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:is_face() then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)()) then
                card.ability.extra.mult = (card.ability.extra.mult) + 2
            elseif (context.scoring_name == "High Card" and (function()
    local allMatchRank = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:get_id() == 14) then
            allMatchRank = false
            break
        end
    end
    
    return allMatchRank and #context.scoring_hand > 0
end)()) then
                card.ability.extra.xmult2 = (card.ability.extra.xmult2) + 0.1
                card.ability.extra.chips = (card.ability.extra.chips) + 11
            elseif (not (context.scoring_name ~= "High Card") or not ((function()
    local allMatchRank = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:get_id() == 14) then
            allMatchRank = false
            break
        end
    end
    
    return allMatchRank and #context.scoring_hand > 0
end)())) then
                card.ability.extra.xmult2 = 1
            else
                return {
                    mult = card.ability.extra.mult,
                    extra = {
                        chips = card.ability.extra.chips,
                        colour = G.C.CHIPS,
                        extra = {
                            Xmult = card.ability.extra.xmult1,
                        extra = {
                            Xmult = card.ability.extra.xmult2
                        }
                        }
                        }
                }
            end
        end
        if context.repetition and context.cardarea == G.play  then
            if ((function()
        local enhancements = SMODS.get_enhancements(context.other_card)
        for k, v in pairs(enhancements) do
            if v then
                return true
            end
        end
        return false
    end)() and context.other_card:get_id() == 14) then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 14 then
                return {
                    mult = card.ability.extra.mult2,
                    extra = {
                        chips = card.ability.extra.chips2,
                        colour = G.C.CHIPS
                        }
                }
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_ed5ba84a', 1, card.ability.extra.odds, 'j_redditor_divinumace') then
                      assert(SMODS.change_base(context.other_card, nil, "Ace"))
                local enhancement_pool = {}
                for _, enhancement in pairs(G.P_CENTER_POOLS.Enhanced) do
                    if enhancement.key ~= 'm_stone' then
                        enhancement_pool[#enhancement_pool + 1] = enhancement
                    end
                end
                local random_enhancement = pseudorandom_element(enhancement_pool, 'edit_card_enhancement')
                context.other_card:set_ability(random_enhancement)
                local random_edition = poll_edition('edit_card_edition', nil, true, true)
                if random_edition then
                    context.other_card:set_edition(random_edition, true)
                end
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
                  end
            end
        end
        if context.after and context.cardarea == G.jokers  then
            if G.GAME.current_round.hands_left == 1 then
                return {
                    func = function()
                local card_front = pseudorandom_element({G.P_CARDS.S_A, G.P_CARDS.H_A, G.P_CARDS.D_A, G.P_CARDS.C_A}, pseudoseed('add_card_hand_suit'))
                local new_card = create_playing_card({
                    front = card_front,
                    center = pseudorandom_element({G.P_CENTERS.m_gold, G.P_CENTERS.m_steel, G.P_CENTERS.m_glass, G.P_CENTERS.m_wild, G.P_CENTERS.m_mult, G.P_CENTERS.m_lucky, G.P_CENTERS.m_stone}, pseudoseed('add_card_hand_enhancement'))
                }, G.discard, true, false, nil, true)
            new_card:set_seal(pseudorandom_element({"Gold", "Red", "Blue", "Purple"}, pseudoseed('add_card_hand_seal')), true)
            new_card:set_edition(pseudorandom_element({"e_foil", "e_holo", "e_polychrome", "e_negative"}, pseudoseed('add_card_hand_edition')), true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                new_card.playing_card = G.playing_card
                table.insert(G.playing_cards, new_card)
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.hand:emplace(new_card)
                        new_card:start_materialize()
                        SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
                        return true
                    end
                }))
            end,
                    message = "Added Card to Hand!"
                }
            end
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
    end,

    remove_from_deck = function(self, card, from_debuff)
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
    end
}


local card_get_id_ref = Card.get_id
function Card:get_id()
    local original_id = card_get_id_ref(self)
    if not original_id then return original_id end

    if next(SMODS.find_card("j_redditor_divinumace")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 2 end
        end
    end
    if next(SMODS.find_card("j_redditor_divinumace")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 3 end
        end
    end
    if next(SMODS.find_card("j_redditor_divinumace")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 4 end
        end
    end
    if next(SMODS.find_card("j_redditor_divinumace")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 5 end
        end
    end
    if next(SMODS.find_card("j_redditor_divinumace")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 6 end
        end
    end
    if next(SMODS.find_card("j_redditor_divinumace")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 7 end
        end
    end
    if next(SMODS.find_card("j_redditor_divinumace")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 8 end
        end
    end
    if next(SMODS.find_card("j_redditor_divinumace")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 9 end
        end
    end
    if next(SMODS.find_card("j_redditor_divinumace")) then
        local source_ids = {14}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 10 end
        end
    end
    return original_id
end
