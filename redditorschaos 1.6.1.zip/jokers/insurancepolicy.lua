SMODS.Joker{ --Insurance Policy
    key = "insurancepolicy",
    config = {
        extra = {
            odds = 10,
            dollars = 20
        }
    },
    loc_txt = {
        ['name'] = 'Insurance Policy',
        ['text'] = {
            [1] = '{C:green}#1# in #2#{} to gain {C:money}$20{} when a {C:attention}Glass{} card is {C:red}destroyed{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 8
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return not args or args.source ~= 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
      end
    ,

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_redditor_insurancepolicy') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.remove_playing_cards  then
            if (function()
    for k, removed_card in ipairs(context.removed) do
        if removed_card.shattered then
            return true
        end
    end
    return false
end)() then
                if SMODS.pseudorandom_probability(card, 'group_0_c0db0450', 1, card.ability.extra.odds, 'j_redditor_insurancepolicy') then
                      SMODS.calculate_effect({dollars = card.ability.extra.dollars}, card)
                  end
            end
        end
    end
}