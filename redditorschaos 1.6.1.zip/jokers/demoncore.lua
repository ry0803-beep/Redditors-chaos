SMODS.Joker{ --Demon Core
    key = "demoncore",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Demon Core',
        ['text'] = {
            [1] = 'All {C:attention}scored{} cards become {C:attention}Irradiated{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 4
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return not args or args.source ~= 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
      end
    ,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                context.other_card:set_ability(G.P_CENTERS.m_redditor_irradiated)
                return {
                    message = "Card Modified!"
                }
        end
    end
}