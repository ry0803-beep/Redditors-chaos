SMODS.Joker{ --Abuction
    key = "abuction",
    config = {
        extra = {
            xmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Abuction',
        ['text'] = {
            [1] = 'When you Play a {C:attention}#2#{} of {C:attention}#1#s{}',
            [2] = 'Destroy it and this card gains {X:red,C:white}X1{} Mult',
            [3] = '{C:inactive}(currently{} {X:red,C:white}X#3#{} {C:inactive}Mult){}',
            [4] = '{C:inactive}(Changes every round){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return not args or args.source ~= 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
      end
    ,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult, localize((G.GAME.current_round.suit_card or {}).suit or 'Spades', 'suits_singular'), localize((G.GAME.current_round.rank_card or {}).rank or 'Ace', 'ranks')}, colours = {G.C.SUITS[(G.GAME.current_round.suit_card or {}).suit or 'Spades']}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.suit_card = { suit = 'Clubs' }
        G.GAME.current_round.rank_card = { rank = 'Ace', id = 14 }
    end,

    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if (context.other_card:get_id() == G.GAME.current_round.rank_card.id and context.other_card:is_suit(G.GAME.current_round.suit_card.suit)) then
                context.other_card.should_destroy = true
                card.ability.extra.xmult = (card.ability.extra.xmult) + 1
                return {
                    message = "Abducted"
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                if G.playing_cards then
                    local valid_suit_cards = {}
                    for _, v in ipairs(G.playing_cards) do
                        if not SMODS.has_no_suit(v) then
                            valid_suit_cards[#valid_suit_cards + 1] = v
                        end
                    end
                    if valid_suit_cards[1] then
                        local suit_card = pseudorandom_element(valid_suit_cards, pseudoseed('suit' .. G.GAME.round_resets.ante))
                        G.GAME.current_round.suit_card.suit = suit_card.base.suit
                    end
                end
                if G.playing_cards then
                        local valid_rank_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_rank_cards[#valid_rank_cards + 1] = v
                            end
                        end
                        if valid_rank_cards[1] then
                            local rank_card = pseudorandom_element(valid_rank_cards, pseudoseed('rank' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.rank_card.rank = rank_card.base.value
                            G.GAME.current_round.rank_card.id = rank_card.base.id
                        end
                    end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.xmult
                }
        end
    end
}