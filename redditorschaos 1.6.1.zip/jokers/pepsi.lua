SMODS.Joker{ --Pepsi
    key = "pepsi",
    config = {
        extra = {
            handsleft = 10,
            repetitions = 1
        }
    },
    loc_txt = {
        ['name'] = 'Pepsi',
        ['text'] = {
            [1] = 'Retrigger all cards played for the next {C:attention}#1#{} hands'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 10
    },
    cost = 6,
    rarity = "redditor_pepsi",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return not args or args.source ~= 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
      end
    ,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.handsleft}}
    end,

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if (card.ability.extra.handsleft or 0) > 0 then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.setting_blind  then
            if (card.ability.extra.handsleft or 0) == 0 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Destroyed!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                card.ability.extra.handsleft = math.max(0, (card.ability.extra.handsleft) - 1)
        end
    end
}