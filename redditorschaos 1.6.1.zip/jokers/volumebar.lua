SMODS.Joker{ --Volume Bar
    key = "volumebar",
    config = {
        extra = {
            source_rank_type = "specific",
            source_ranks = {"5"},
            target_rank = "2",
            source_rank_type = "specific",
            source_ranks = {"5"},
            target_rank = "4",
            source_rank_type = "specific",
            source_ranks = {"5"},
            target_rank = "6",
            source_rank_type = "specific",
            source_ranks = {"5"},
            target_rank = "8",
            source_rank_type = "specific",
            source_ranks = {"5"},
            target_rank = "10"
        }
    },
    loc_txt = {
        ['name'] = 'Volume Bar',
        ['text'] = {
            [1] = '{C:attention}5{}s count as all',
            [2] = '{C:attention}Even Numbered cards{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 15
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return not args or args.source ~= 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
      end
    ,

    calculate = function(self, card, context)
    end,

    add_to_deck = function(self, card, from_debuff)
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
        -- Combine ranks effect enabled
    end,

    remove_from_deck = function(self, card, from_debuff)
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
        -- Combine ranks effect disabled
    end
}


local card_get_id_ref = Card.get_id
function Card:get_id()
    local original_id = card_get_id_ref(self)
    if not original_id then return original_id end

    if next(SMODS.find_card("j_redditor_volumebar")) then
        local source_ids = {5}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 2 end
        end
    end
    if next(SMODS.find_card("j_redditor_volumebar")) then
        local source_ids = {5}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 4 end
        end
    end
    if next(SMODS.find_card("j_redditor_volumebar")) then
        local source_ids = {5}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 6 end
        end
    end
    if next(SMODS.find_card("j_redditor_volumebar")) then
        local source_ids = {5}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 8 end
        end
    end
    if next(SMODS.find_card("j_redditor_volumebar")) then
        local source_ids = {5}
        for _, source_id in pairs(source_ids) do
            if original_id == source_id then return 10 end
        end
    end
    return original_id
end
