SMODS.Joker{ --Glass House
    key = "glasshouse",
    config = {
        extra = {
            mult = 10
        }
    },
    loc_txt = {
        ['name'] = 'Glass House',
        ['text'] = {
            [1] = '{C:red}+10 Mult{} when a {C:attention}Glass{} card is {C:attention}Scored{}',
            [2] = 'when a {C:attention}Glass{} card is {C:red}destroyed{} this card loses {C:red}1 Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 6
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return not args or args.source ~= 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
      end
    ,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_glass"] == true then
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
        if context.remove_playing_cards  then
            if (function()
    for k, removed_card in ipairs(context.removed) do
        if removed_card.shattered then
            return true
        end
    end
    return false
end)() then
                return {
                    func = function()
                    card.ability.extra.mult = math.max(0, (card.ability.extra.mult) - 1)
                    return true
                end
                }
            elseif (card.ability.extra.mult or 0) == 1 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Shattered"
                }
            end
        end
    end
}