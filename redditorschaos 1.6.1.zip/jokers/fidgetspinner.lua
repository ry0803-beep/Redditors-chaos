SMODS.Joker{ --Fidget Spinner
    key = "fidgetspinner",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Fidget Spinner',
        ['text'] = {
            [1] = 'If hand contains a {C:attention}#1#{}, {C:attention}#2#{} and {C:attention}#3#{}',
            [2] = 'Create a {C:attention}Boss Tag{}',
            [3] = '{C:inactive}(ranks change each hand){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 5
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return not args or args.source ~= 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
      end
    ,

    loc_vars = function(self, info_queue, card)
        return {vars = {localize((G.GAME.current_round.rank_card or {}).rank or 'Ace', 'ranks'), localize((G.GAME.current_round.rank2_card or {}).rank or 'Ace', 'ranks'), localize((G.GAME.current_round.rank3_card or {}).rank or 'Ace', 'ranks')}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.rank_card = { rank = 'King', id = 13 }
        G.GAME.current_round.rank2_card = { rank = 'Ace', id = 14 }
        G.GAME.current_round.rank3_card = { rank = '2', id = 2 }
    end,

    calculate = function(self, card, context)
        if context.after and context.cardarea == G.jokers  then
                if G.playing_cards then
                        local valid_rank_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_rank_cards[#valid_rank_cards + 1] = v
                            end
                        end
                        if valid_rank_cards[1] then
                            local rank_card = pseudorandom_element(valid_rank_cards, pseudoseed('rank' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.rank_card.rank = rank_card.base.value
                            G.GAME.current_round.rank_card.id = rank_card.base.id
                        end
                    end
                if G.playing_cards then
                        local valid_rank2_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_rank2_cards[#valid_rank2_cards + 1] = v
                            end
                        end
                        if valid_rank2_cards[1] then
                            local rank2_card = pseudorandom_element(valid_rank2_cards, pseudoseed('rank2' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.rank2_card.rank = rank2_card.base.value
                            G.GAME.current_round.rank2_card.id = rank2_card.base.id
                        end
                    end
                if G.playing_cards then
                        local valid_rank3_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_rank3_cards[#valid_rank3_cards + 1] = v
                            end
                        end
                        if valid_rank3_cards[1] then
                            local rank3_card = pseudorandom_element(valid_rank3_cards, pseudoseed('rank3' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.rank3_card.rank = rank3_card.base.value
                            G.GAME.current_round.rank3_card.id = rank3_card.base.id
                        end
                    end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == G.GAME.current_round.rank3_card.id then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)() and (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == G.GAME.current_round.rank2_card.id then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)() and (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == G.GAME.current_round.rank_card.id then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)()) then
            end
        end
    end
}