SMODS.Joker{ --Numbera Infinita
    key = "numberainfinita",
    config = {
        extra = {
            xmult = 1,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Numbera Infinita',
        ['text'] = {
            [1] = 'When a {C:attention}Numbered{} card is {C:red}Destroyed{}',
            [2] = 'this card gains {X:red,C:white}X0.5{} Mult',
            [3] = '{C:inactive}(currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 10
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return not args or args.source ~= 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
      end
    ,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.remove_playing_cards  then
            if ((function()
    for k, removed_card in ipairs(context.removed) do
        if removed_card:get_id() == 2 then
            return true
        end
    end
    return false
end)() or (function()
    for k, removed_card in ipairs(context.removed) do
        if removed_card:get_id() == 3 then
            return true
        end
    end
    return false
end)() or (function()
    for k, removed_card in ipairs(context.removed) do
        if removed_card:get_id() == 4 then
            return true
        end
    end
    return false
end)() or (function()
    for k, removed_card in ipairs(context.removed) do
        if removed_card:get_id() == 5 then
            return true
        end
    end
    return false
end)() or (function()
    for k, removed_card in ipairs(context.removed) do
        if removed_card:get_id() == 6 then
            return true
        end
    end
    return false
end)() or (function()
    for k, removed_card in ipairs(context.removed) do
        if removed_card:get_id() == 7 then
            return true
        end
    end
    return false
end)() or (function()
    for k, removed_card in ipairs(context.removed) do
        if removed_card:get_id() == 8 then
            return true
        end
    end
    return false
end)() or (function()
    for k, removed_card in ipairs(context.removed) do
        if removed_card:get_id() == 9 then
            return true
        end
    end
    return false
end)() or (function()
    for k, removed_card in ipairs(context.removed) do
        if removed_card:get_id() == 10 then
            return true
        end
    end
    return false
end)()) then
                return {
                    func = function()
                    card.ability.extra.var1 = (card.ability.extra.var1) + 0.5
                    return true
                end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.xmult
                }
        end
    end
}