SMODS.Joker{ --Big Dragons
    key = "bigdragons",
    config = {
        extra = {
            mult = 0,
            Xmult = 3
        }
    },
    loc_txt = {
        ['name'] = 'Big Dragons',
        ['text'] = {
            [1] = '{X:red,C:white}X3{} Mult if hand has at least',
            [2] = '{C:attention}3{} scoring',
            [3] = '{C:gold}Gold{}/{C:attention}Steel{}/Stone cards'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    cost = 6,
    rarity = "redditor_mahjong",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return not args or args.source ~= 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
      end
    ,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_gold"] == true then
            count = count + 1
        end
    end
    return count >= 3
end)() or (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_steel"] == true then
            count = count + 1
        end
    end
    return count >= 3
end)() or (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_stone"] == true then
            count = count + 1
        end
    end
    return count >= 3
end)()) then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}