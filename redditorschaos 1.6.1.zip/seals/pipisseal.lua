SMODS.Seal {
    key = 'pipisseal',
    pos = { x = 5, y = 0 },
    badge_colour = HEX('1E90FF'),
   loc_txt = {
        name = 'Pipis Seal',
        label = 'Pipis Seal',
        text = {
        [1] = 'When this card is {C:attention}scored{}',
        [2] = 'create a random {C:attention}consumable{}',
        [3] = 'and {C:red}destroy{} this card'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            G.E_MANAGER:add_event(Event({
                func = function()
                    card:start_dissolve()
                    return true
                end
            }))
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Destroyed!", colour = G.C.RED})
            return
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            local random_sets = {'Tarot', 'Planet', 'Spectral'}
                            local random_set = random_sets[math.random(1, #random_sets)]
                            SMODS.add_card{set=random_set, key_append='enhanced_card_' .. random_set:lower()}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
            card.should_destroy = true
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_consumable and "+1 Consumable!" or nil, colour = G.C.PURPLE})
        end
    end
}