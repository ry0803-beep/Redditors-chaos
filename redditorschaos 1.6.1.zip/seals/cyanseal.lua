SMODS.Seal {
    key = 'cyanseal',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            odds = 8,
            levels = 1
        }
    },
    badge_colour = HEX('45B7D1'),
   loc_txt = {
        name = 'Cyan Seal',
        label = 'Cyan Seal',
        text = {
        [1] = 'When this card is {C:attention}scored{} {C:green}#1# in #2#{}',
        [2] = 'chance to upgrade {C:attention}Played hand{}'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.seal.extra.odds, 'redditor_cyanseal')
        return {vars = {numerator, denominator}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(card, 'group_0_a5f62312', 1, card.ability.seal.extra.odds, 'm_redditor') then
                local target_hand
                target_hand = context.scoring_name or "High Card"
                SMODS.calculate_effect({level_up = card.ability.extra.levels,
                level_up_hand = target_hand}, card)
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_level_up_ex'), colour = G.C.RED})
            end
        end
    end
}