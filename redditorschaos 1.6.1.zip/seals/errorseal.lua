SMODS.Seal {
    key = 'errorseal',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            x_mult = 1.5
        }
    },
    badge_colour = HEX('000000'),
   loc_txt = {
        name = 'Error Seal',
        label = 'Error Seal',
        text = {
        [1] = '{X:red,C:white}X1.5{} Mult',
        [2] = '{C:red}Destroy{} a random {C:attention}consumable{}',
        [3] = 'when this card is scored'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            local target_cards = {}
            for i, consumable in ipairs(G.consumeables.cards) do
                table.insert(target_cards, consumable)
            end
            if #target_cards > 0 then
                local card_to_destroy = pseudorandom_element(target_cards, pseudoseed('destroy_consumable'))
                G.E_MANAGER:add_event(Event({
                    func = function()
                        card_to_destroy:start_dissolve()
                        return true
                    end
                }))
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed Consumable!", colour = G.C.RED})
            end
            SMODS.calculate_effect({x_mult = card.ability.seal.extra.x_mult}, card)
        end
    end
}