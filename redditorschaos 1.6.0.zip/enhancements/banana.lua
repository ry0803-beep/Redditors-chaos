SMODS.Enhancement {
    key = 'banana',
    pos = { x = 4, y = 0 },
    config = {
        mult = 15,
        extra = {
            odds = 6
        }
    },
    loc_txt = {
        name = 'Banana',
        text = {
        [1] = '{C:red}+15 Mult{} when scored',
        [2] = '{C:green}#1# in #2#{} chance this card',
        [3] = '{C:red}Destroys{} itself when scored'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    shatters = true,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'm_redditor_banana')
        return {vars = {15, numerator, denominator}}
    end,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            return { remove = true }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            if SMODS.pseudorandom_probability(card, 'group_0_ab493aee', 1, card.ability.extra.odds, 'm_redditor') then
                card.should_destroy = true
            end
        end
    end
}