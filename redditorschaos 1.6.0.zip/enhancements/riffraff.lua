SMODS.Enhancement {
    key = 'riffraff',
    pos = { x = 0, y = 2 },
    config = {
        extra = {
            odds = 10
        }
    },
    loc_txt = {
        name = 'Riff Raff',
        text = {
        [1] = '{C:green}#1# in #2#{} chance to create a',
        [2] = '{C:dark_edition}Negative{} {C:common}Common{} {C:attention}Joker{}',
        [3] = 'when this card is scored'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'm_redditor_riffraff')
        return {vars = {numerator, denominator}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(card, 'group_0_e5fa8d60', 1, card.ability.extra.odds, 'm_redditor') then
                local created_joker = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'Common' })
                        if joker_card then
                            
                            
                        end
                        
                        return true
                    end
                }))
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_joker and localize('k_plus_joker') or nil, colour = G.C.BLUE})
            end
        end
    end
}