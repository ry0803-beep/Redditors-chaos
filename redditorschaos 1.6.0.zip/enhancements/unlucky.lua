SMODS.Enhancement {
    key = 'unlucky',
    pos = { x = 3, y = 2 },
    config = {
        bonus = 200,
        extra = {
            odds = 5,
            odds2 = 15,
            mult = -100,
            dollars = 20
        }
    },
    loc_txt = {
        name = 'Unlucky',
        text = {
        [1] = '{C:blue}+200 Chips{}',
        [2] = '{C:green}1 in 5{} chance for {C:red}-100{} Mult',
        [3] = '{C:green}1 in 15{} chance to lose {C:money}$20{}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(card, 'group_0_63960e75', 1, card.ability.extra.odds, 'm_redditor') then
                SMODS.calculate_effect({mult = card.ability.extra.mult}, card)
            end
            if SMODS.pseudorandom_probability(card, 'group_1_62461abc', 1, card.ability.extra.odds2, 'm_redditor') then
                SMODS.calculate_effect({dollars = -lenient_bignum(card.ability.extra.dollars)}, card)
            end
        end
    end
}