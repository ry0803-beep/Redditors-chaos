SMODS.Joker{ --Tension
    key = "tension",
    config = {
        extra = {
            mult = 0,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Tension',
        ['text'] = {
            [1] = 'This card gains {C:red}+1 Mult{} when',
            [2] = 'a {C:attention}10{} is {C:red}discarded{}',
            [3] = '{C:inactive}(currently{} {C:red}+#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 14
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult}}
    end,

    calculate = function(self, card, context)
        if context.discard  then
            if (function()
    local rankFound = false
    for i, c in ipairs(context.full_hand) do
        if c:get_id() == 10 then
            rankFound = true
            break
        end
    end
    
    return rankFound
end)() then
                return {
                    func = function()
                    card.ability.extra.var1 = (card.ability.extra.var1) + 1
                    return true
                end
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.mult
                }
        end
    end
}