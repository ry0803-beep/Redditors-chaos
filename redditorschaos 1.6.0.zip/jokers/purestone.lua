SMODS.Joker{ --Pure Stone
    key = "purestone",
    config = {
        extra = {
            emult = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Pure Stone',
        ['text'] = {
            [1] = '{X:red,C:white}^1.5{} Mult'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 11
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    e_mult = card.ability.extra.emult
                }
        end
    end
}