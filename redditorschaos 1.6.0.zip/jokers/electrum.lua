SMODS.Joker{ --Electrum
    key = "electrum",
    config = {
        extra = {
            Xmult = 1.5,
            dollars = 3
        }
    },
    loc_txt = {
        ['name'] = 'Electrum',
        ['text'] = {
            [1] = '{C:gold}Gold{} {C:attention}cards{} give {X:red,C:white}X1.5{} Mult',
            [2] = 'while held in hand',
            [3] = 'and {C:attention}Steel{} {C:attention}cards{} give {C:money}$3{}',
            [4] = 'while held in hand',
            [5] = 'at the end of round'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 5
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_gold"] == true then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
        if context.cardarea == G.hand and context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_steel"] == true then
                return {
                    dollars = card.ability.extra.dollars
                }
            end
        end
    end
}