SMODS.Joker{ --Connoisseur
    key = "connoisseur",
    config = {
        extra = {
            stuffbought = 0,
            xmult = 1,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Connoisseur',
        ['text'] = {
            [1] = 'This card gains {X:red,C:white}X0.25{} Mult for each consecutive',
            [2] = 'time you exit the shop with only buying {C:attention}2{} things',
            [3] = '{C:inactive}(currently{} {X:red,C:white}X#2#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 3
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.stuffbought, card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.buying_card  then
                return {
                    func = function()
                    card.ability.extra.var1 = (card.ability.extra.var1) + 1
                    return true
                end
                }
        end
        if context.ending_shop  then
            if (card.ability.extra.stuffbought or 0) == 2 then
                return {
                    func = function()
                    card.ability.extra.xmult = (card.ability.extra.xmult) + 0.25
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.stuffbought = 0
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
            elseif not ((card.ability.extra.stuffbought or 0) == 2) then
                return {
                    func = function()
                    card.ability.extra.stuffbought = 0
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.xmult = 1
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
            end
        end
    end
}