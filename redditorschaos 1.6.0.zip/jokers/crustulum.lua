SMODS.Joker{ --Crustulum
    key = "crustulum",
    config = {
        extra = {
            Chips = 0,
            dollars = 4
        }
    },
    loc_txt = {
        ['name'] = 'Crustulum',
        ['text'] = {
            [1] = 'When you reroll this card Gains',
            [2] = '{C:blue}+4 Chips{} and you gain {C:money}$4{}',
            [3] = '{C:inactive}(currently {C:blue}+#1#{} {C:inactive}Chips){}{}',
            [4] = '{C:inactive,s:0.7}(the cake is a lie){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 3
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Chips}}
    end,

    calculate = function(self, card, context)
        if context.reroll_shop  then
                return {
                    func = function()
                    card.ability.extra.Chips = (card.ability.extra.Chips) + 4
                    return true
                end,
                    extra = {
                        dollars = card.ability.extra.dollars,
                        colour = G.C.MONEY
                        }
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.Chips
                }
        end
    end
}