SMODS.Joker{ --Steel Card
    key = "steelcard",
    config = {
        extra = {
            Xmult = 1.25
        }
    },
    loc_txt = {
        ['name'] = 'Steel Card',
        ['text'] = {
            [1] = '{X:red,C:white}X1.25{} Mult when a {C:attention}Steel{} card is scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 13
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_steel"] == true then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}