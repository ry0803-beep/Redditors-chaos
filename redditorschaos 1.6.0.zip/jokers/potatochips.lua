SMODS.Joker{ --Potato Chips
    key = "potatochips",
    config = {
        extra = {
            xmult = 3
        }
    },
    loc_txt = {
        ['name'] = 'Potato Chips',
        ['text'] = {
            [1] = '{X:red,C:white}X#1#{} Mult',
            [2] = 'this card loses {X:red,C:white}X0.2{} Mult',
            [3] = 'per hand played'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 11
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                local xmult_value = card.ability.extra.xmult
                card.ability.extra.xmult = math.max(0, (card.ability.extra.xmult) - 0.2)
                return {
                    Xmult = xmult_value
                }
        end
    end
}