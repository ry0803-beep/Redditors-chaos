SMODS.Joker{ --Prism
    key = "prism",
    config = {
        extra = {
            levels = 2,
            levels2 = 2,
            Straight = 0,
            Flush = 0
        }
    },
    loc_txt = {
        ['name'] = 'Prism',
        ['text'] = {
            [1] = 'If {C:attention}Played hand{} is a {C:attention}Straight Flush{},',
            [2] = 'upgrade {C:attention}Straight{} and {C:attention}Flush{} by {C:attention}2{} levels'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 11
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if context.scoring_name == "Straight Flush" then
                target_hand = "Straight"
                target_hand2 = "Flush"
                return {
                    level_up = card.ability.extra.levels,
      level_up_hand = target_hand,
                    message = localize('k_level_up_ex'),
                    extra = {
                        level_up = card.ability.extra.levels2,
      level_up_hand = target_hand2,
                            message = localize('k_level_up_ex'),
                        colour = G.C.RED
                        }
                }
            end
        end
    end
}