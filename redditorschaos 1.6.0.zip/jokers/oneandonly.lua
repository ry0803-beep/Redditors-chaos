SMODS.Joker{ --One And Only
    key = "oneandonly",
    config = {
        extra = {
            chips = 0
        }
    },
    loc_txt = {
        ['name'] = 'One And Only',
        ['text'] = {
            [1] = 'this card gains {C:blue}+11 Chips{} if hand',
            [2] = 'is a {C:attention}Ace High Card{}',
            [3] = '{C:inactive}(currently {}{C:blue}+#1#{} {C:inactive}Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 10
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.chips}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (context.scoring_name == "High Card" and (function()
    local allMatchRank = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:get_id() == 14) then
            allMatchRank = false
            break
        end
    end
    
    return allMatchRank and #context.scoring_hand > 0
end)()) then
                card.ability.extra.chips = (card.ability.extra.chips) + 11
            else
                return {
                    chips = card.ability.extra.chips
                }
            end
        end
    end
}