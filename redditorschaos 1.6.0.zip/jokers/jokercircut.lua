SMODS.Joker{ --Joker Circut
    key = "jokercircut",
    config = {
        extra = {
            handleft = 2,
            speed = 0
        }
    },
    loc_txt = {
        ['name'] = 'Joker Circut',
        ['text'] = {
            [1] = 'When you Play {C:attention}3 Straights{} gain a {C:attention}Speed Tag{}',
            [2] = '{C:inactive}({}{C:attention}#1#{} {C:inactive}straights left){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 8
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.handleft}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (card.ability.extra.handleft or 0) == 0 then
                G.E_MANAGER:add_event(Event({
                func = function()
                    local tag = Tag("tag_speed")
                    if tag.name == "Orbital Tag" then
                        local _poker_hands = {}
                        for k, v in pairs(G.GAME.hands) do
                            if v.visible then
                                _poker_hands[#_poker_hands + 1] = k
                            end
                        end
                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                    end
                    tag:set_ability()
                    add_tag(tag)
                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                    return true
                end
            }))
                card.ability.extra.handleft = 2
                return {
                    message = "Created Tag!"
                }
            else
                card.ability.extra.handleft = math.max(0, (card.ability.extra.handleft) - 1)
            end
        end
    end
}