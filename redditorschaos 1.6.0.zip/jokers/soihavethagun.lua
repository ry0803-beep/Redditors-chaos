SMODS.Joker{ --So I Haveth A Gun
    key = "soihavethagun",
    config = {
        extra = {
            number = 1,
            pb_x_mult_fc3af702 = 0.1,
            perma_x_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'So I Haveth A Gun',
        ['text'] = {
            [1] = 'The {C:attention}#1#th{} card in the {C:attention}Played hand{} gains {X:red,C:white}X0.1{} Mult',
            [2] = 'permanently when scored',
            [3] = '{C:inactive}(card position changes each hand){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 12
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.number}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card == context.scoring_hand[card.ability.extra.number] then
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult or 0
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult + card.ability.extra.pb_x_mult_fc3af702
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.MULT }, card = card
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.number = pseudorandom('number_ccb80c67', 1, 5)
                    return true
                end
                }
        end
    end
}