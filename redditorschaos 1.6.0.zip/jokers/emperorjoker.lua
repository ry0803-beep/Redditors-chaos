SMODS.Joker{ --Emperor Joker
    key = "emperorjoker",
    config = {
        extra = {
            dollars = 3
        }
    },
    loc_txt = {
        ['name'] = 'Emperor Joker',
        ['text'] = {
            [1] = 'When a {C:attention}Jack{} is scored',
            [2] = 'make it a {C:attention}Knight{} card',
            [3] = '{C:attention}Kings{} give {C:money}$3{} when held in hand'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 5
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 3,
        y = 5
    },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 11 then
                context.other_card:set_ability(G.P_CENTERS.m_redditor_knight)
                return {
                    message = "Card Modified!"
                }
            end
        end
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
                return {
                    dollars = card.ability.extra.dollars
                }
        end
    end
}