SMODS.Seal {
    key = 'orangeseal',
    pos = { x = 4, y = 0 },
    config = {
        extra = {
            card_draw = 3
        }
    },
    badge_colour = HEX('FF4500'),
   loc_txt = {
        name = 'Orange Seal',
        label = 'Orange Seal',
        text = {
        [1] = 'When this card is {C:red}Discarded{}',
        [2] = 'draw {C:attention}3{} cards'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.discard and context.other_card == card then
            if G.GAME.blind.in_blind then
    SMODS.draw_cards(card.ability.extra.card_draw)
  end
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.card_draw).." Cards Drawn", colour = G.C.BLUE})
        end
    end
}