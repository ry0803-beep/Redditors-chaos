SMODS.Enhancement {
    key = 'an10na',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            x_mult = 1.1,
            retrigger_times = 1
        }
    },
    loc_txt = {
        name = 'An10na',
        text = {
        [1] = 'If this card rank is an {C:attention}10{}',
        [2] = '{C:attention}Retrigger{} this card and gain {X:red,C:white}X1.1{} Mult',
        [3] = 'When this card is scored'
    }
    },
    atlas = 'CustomEnhancements',
    pos = { x = 0, y = 0 },
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.repetition and card.should_retrigger then
            return { repetitions = card.ability.extra.retrigger_times }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_retrigger = false
            if card:get_id() == 10 then
                card.should_retrigger = true
            SMODS.calculate_effect({x_mult = card.ability.extra.x_mult}, card)
            end
        end
    end
}