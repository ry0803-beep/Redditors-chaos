SMODS.Joker{ --Bop It
    key = "bopit",
    config = {
        extra = {
            xmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Bop It',
        ['text'] = {
            [1] = 'this card gains {X:red,C:white}X0.8{} Mult if {C:attention}Played hand{}',
            [2] = 'is a {C:attention}#1#{}, resets otherwise',
            [3] = '{C:inactive}(currently{} {X:red,C:white}X#2#{} {C:inactive}Mult){}',
            [4] = '{C:inactive}(resets each hand){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult, localize((G.GAME.current_round.pokervar_hand or 'High Card'), 'poker_hands')}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.pokervar_hand = 'High Card'
    end,

    calculate = function(self, card, context)
        if context.after and context.cardarea == G.jokers  then
                local pokervar_hands = {}
                for handname, _ in pairs(G.GAME.hands) do
                    if G.GAME.hands[handname].visible then
                        pokervar_hands[#pokervar_hands + 1] = handname
                    end
                end
                if pokervar_hands[1] then
                    G.GAME.current_round.pokervar_hand = pseudorandom_element(pokervar_hands, pseudoseed('pokervar' .. G.GAME.round_resets.ante))
                end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if context.scoring_name == G.GAME.current_round.pokervar_hand then
                card.ability.extra.xmult = (card.ability.extra.xmult) + 0.8
            else
                return {
                    Xmult = card.ability.extra.xmult
                }
            end
        end
    end
}