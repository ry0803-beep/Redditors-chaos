SMODS.Joker{ --One-Machine Army
    key = "onemachinearmy",
    config = {
        extra = {
            chips = 170,
            Tarot = 0
        }
    },
    loc_txt = {
        ['name'] = 'One-Machine Army',
        ['text'] = {
            [1] = 'If {C:attention}Played hand{} contains a {C:attention}Straight{} and a {C:attention}4{}',
            [2] = '{C:blue}+170 Chips{} and create a random {C:tarot}Tarot{} {C:attention}card{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 8
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (next(context.poker_hands["Straight"]) and (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 4 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)()) then
                local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Tarot', key = nil, key_append = 'joker_forge_tarot'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        message = created_consumable and localize('k_plus_tarot') or nil,
                        colour = G.C.PURPLE
                        }
                }
            end
        end
    end
}