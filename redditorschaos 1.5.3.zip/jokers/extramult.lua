SMODS.Joker{ --Extramult
    key = "extramult",
    config = {
        extra = {
            perma_bonus = 5,
            perma_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Extramult',
        ['text'] = {
            [1] = 'Every played {C:attention}card{} permanently',
            [2] = 'gains {C:red}+5{} Mult when scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.extra.perma_bonus
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card
                }
        end
    end
}