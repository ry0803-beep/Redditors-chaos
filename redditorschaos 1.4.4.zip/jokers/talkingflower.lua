SMODS.Joker{ --Talking Flower
    key = "talkingflower",
    config = {
        extra = {
            mult = 4
        }
    },
    loc_txt = {
        ['name'] = 'Talking Flower',
        ['text'] = {
            [1] = '{C:attention}+1{} Joker slot',
            [2] = '{C:red}+4 Mult{}',
            [3] = '{C:inactive}(has things to say about your run){}'
        }
    },
    pos = {
        x = 1,
        y = 9
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.mult,
                    extra = {
                        message = "Mult Time",
                        colour = G.C.RED
                        }
                }
        end
        if context.buying_card  then
                return {
                    message = "Good Choice"
                }
        end
        if context.selling_self  then
                return {
                    message = "Wait no"
                }
        end
        if context.setting_blind  then
            if G.GAME.blind.boss then
                return {
                    message = "Things Are getting serious npw"
                }
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
                return {
                    message = "Onto the next ante"
                }
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        G.jokers.config.card_limit = G.jokers.config.card_limit + 1
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.jokers.config.card_limit = G.jokers.config.card_limit - 1
    end
}