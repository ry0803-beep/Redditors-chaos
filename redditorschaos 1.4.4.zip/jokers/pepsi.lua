SMODS.Joker{ --Pepsi
    key = "pepsi",
    config = {
        extra = {
            handsleft = 10,
            repetitions = 1
        }
    },
    loc_txt = {
        ['name'] = 'Pepsi',
        ['text'] = {
            [1] = 'Retrigger all cards played for the next {C:orange}10{} hands'
        }
    },
    pos = {
        x = 9,
        y = 6
    },
    cost = 6,
    rarity = "redditor_pepsi",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if (card.ability.extra.handsleft or 0) > 0 then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.setting_blind  then
            if (card.ability.extra.handsleft or 0) == 0 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Destroyed!"
                }
            end
        end
    end
}