SMODS.Joker{ --Megaphone
    key = "megaphone",
    config = {
        extra = {
            dollars = 1
        }
    },
    loc_txt = {
        ['name'] = 'Megaphone',
        ['text'] = {
            [1] = '{C:money}$1{} whenever the {C:attention}First card{} triggers'
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card == context.scoring_hand[1] then
                return {
                    dollars = card.ability.extra.dollars
                }
            end
        end
    end
}