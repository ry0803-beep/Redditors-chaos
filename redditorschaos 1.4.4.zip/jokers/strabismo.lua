SMODS.Joker{ --Strabismo
    key = "strabismo",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Strabismo',
        ['text'] = {
            [1] = 'Copy the jokers to the {C:attention}left{} and {C:attention}right{} of this card'
        }
    },
    pos = {
        x = 9,
        y = 8
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        local target_joker = nil
        
        local my_pos = nil
        for i = 1, #G.jokers.cards do
            if G.jokers.cards[i] == card then
                my_pos = i
                break
            end
        end
        target_joker = (my_pos and my_pos < #G.jokers.cards) and G.jokers.cards[my_pos + 1] or nil
        
        return SMODS.blueprint_effect(card, target_joker, context)
    end,

    calculate = function(self, card, context)
        local target_joker = nil
        
        local my_pos = nil
        for i = 1, #G.jokers.cards do
            if G.jokers.cards[i] == card then
                my_pos = i
                break
            end
        end
        target_joker = (my_pos and my_pos > 1) and G.jokers.cards[my_pos - 1] or nil
        
        return SMODS.blueprint_effect(card, target_joker, context)
    end
}