SMODS.Joker{ --The Void
    key = "thevoid",
    config = {
        extra = {
            chips = 100,
            mult = 100
        }
    },
    loc_txt = {
        ['name'] = 'The Void',
        ['text'] = {
            [1] = 'if hand contains no cards Gain',
            [2] = '{C:blue}+100 Chips{} and {C:red}+100 Mult{}'
        }
    },
    pos = {
        x = 3,
        y = 9
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if #context.full_hand < 1 then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        mult = card.ability.extra.mult
                        }
                }
            end
        end
    end
}