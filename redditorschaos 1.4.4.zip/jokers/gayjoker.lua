SMODS.Joker{ --Gay Joker
    key = "gayjoker",
    config = {
        extra = {
            repetitions = 1
        }
    },
    loc_txt = {
        ['name'] = 'Gay Joker',
        ['text'] = {
            [1] = 'Retrigger all Polychrome cards'
        }
    },
    pos = {
        x = 0,
        y = 4
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card.edition and context.other_card.edition.key == "e_polychrome" then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}