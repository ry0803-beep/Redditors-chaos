SMODS.Joker{ --Flower Banquet
    key = "flowerbanquet",
    config = {
        extra = {
            destroy = 0,
            perma_bonus = 0.2,
            perma_x_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Flower Banquet',
        ['text'] = {
            [1] = 'When you play a flush of {C:hearts}Hearts{}',
            [2] = 'convert all scored cards to {C:spades}Spades{},',
            [3] = 'they Permanently Gain {X:red,C:white}X0.2{} Mult',
            [4] = 'and {C:red}Destroy{} this card'
        }
    },
    pos = {
        x = 6,
        y = 3
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.scoring_name == "Flush" and (function()
    local allMatchSuit = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:is_suit("Hearts")) then
            allMatchSuit = false
            break
        end
    end
    
    return allMatchSuit and #context.scoring_hand > 0
end)()) then
                assert(SMODS.change_base(context.other_card, "Spades", nil))
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult or 0
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult + card.ability.extra.perma_bonus
                card.ability.extra.destroy = 1
                return {
                    message = "Card Modified!",
                    extra = {
                        extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card,
                        colour = G.C.CHIPS
                        }
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
            if (card.ability.extra.destroy or 0) == 1 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Destroyed!"
                }
            end
        end
    end
}