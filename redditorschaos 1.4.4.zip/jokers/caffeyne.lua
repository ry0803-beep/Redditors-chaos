SMODS.Joker{ --Caffeyne
    key = "caffeyne",
    config = {
        extra = {
            xmult = 1,
            double = 0
        }
    },
    loc_txt = {
        ['name'] = 'Caffeyne',
        ['text'] = {
            [1] = 'When a Blind is selected gain a Double tag',
            [2] = 'this card gains {X:red,C:white}^0.05{} Mult when a {C:attention}Blind{} is skipped',
            [3] = '{C:inactive}(currently{} {X:red,C:white}^#1#{} {C:inactive}Mult){}'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.setting_blind  then
                return {
                    func = function()
            G.E_MANAGER:add_event(Event({
                func = function()
                    local tag = Tag("tag_double")
                    if tag.name == "Orbital Tag" then
                        local _poker_hands = {}
                        for k, v in pairs(G.GAME.hands) do
                            if v.visible then
                                _poker_hands[#_poker_hands + 1] = k
                            end
                        end
                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                    end
                    tag:set_ability()
                    add_tag(tag)
                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                    return true
                end
            }))
                    return true
                end,
                    message = "Created Tag!"
                }
        end
        if context.skip_blind  then
                return {
                    func = function()
                    card.ability.extra.xmult = (card.ability.extra.xmult) + 0.05
                    return true
                end,
                    message = "Skipped"
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    e_mult = card.ability.extra.xmult
                }
        end
    end
}