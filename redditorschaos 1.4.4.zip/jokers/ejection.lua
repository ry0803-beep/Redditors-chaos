SMODS.Joker{ --Ejection
    key = "ejection",
    config = {
        extra = {
            xmult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Ejection',
        ['text'] = {
            [1] = 'When a {C:attention}#1#{} is Played this card gains',
            [2] = '{X:red,C:white}X0.5{} Mult and those cards get {C:red}Destroyed{}',
            [3] = '{C:inactive}(changes every round){}',
            [4] = '{C:inactive}(currently{} {X:red,C:white}X#2#{} {C:inactive}Mult){}'
        }
    },
    pos = {
        x = 8,
        y = 2
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult, localize((G.GAME.current_round.hand_hand or 'High Card'), 'poker_hands')}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.hand_hand = 'High Card'
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if context.scoring_name == G.GAME.current_round.hand_hand then
                card.ability.extra.xmult = (card.ability.extra.xmult) + 0.5
            else
                return {
                    Xmult = card.ability.extra.xmult
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                local hand_hands = {}
                for handname, _ in pairs(G.GAME.hands) do
                    if G.GAME.hands[handname].visible then
                        hand_hands[#hand_hands + 1] = handname
                    end
                end
                if hand_hands[1] then
                    G.GAME.current_round.hand_hand = pseudorandom_element(hand_hands, pseudoseed('hand' .. G.GAME.round_resets.ante))
                end
        end
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if context.scoring_name == G.GAME.current_round.hand_hand then
                context.other_card.should_destroy = true
                return {
                    message = "Destroyed!"
                }
            end
        end
    end
}