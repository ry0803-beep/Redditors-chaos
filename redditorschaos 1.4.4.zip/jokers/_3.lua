SMODS.Joker{ --:3
    key = "_3",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = ':3',
        ['text'] = {
            [1] = 'Scored {C:attention}3{}s give {C:blue}+3 Chips{} {C:red}+3 Mult{} and {C:attention}$3{}'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers'
}