SMODS.Joker{ --Inkys Upgrade Clubs
    key = "inkysupgradeclubs",
    config = {
        extra = {
            levels = 3
        }
    },
    loc_txt = {
        ['name'] = 'Inkys Upgrade Clubs',
        ['text'] = {
            [1] = 'If a {C:clubs}Club{} is in the {C:attention}Played hand{}',
            [2] = 'upgrade {C:attention}Played hand{} by 3'
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local suitCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:is_suit("Clubs") then
            suitCount = suitCount + 1
        end
    end
    
    return suitCount >= 1
end)() then
                target_hand = context.scoring_name
                return {
                    level_up = card.ability.extra.levels,
      level_up_hand = target_hand,
                    message = localize('k_level_up_ex')
                }
            end
        end
    end
}