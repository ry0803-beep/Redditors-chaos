SMODS.Joker{ --Monkey See, Monkey Do
    key = "monkeyseemonkeydo",
    config = {
        extra = {
            mult = 8
        }
    },
    loc_txt = {
        ['name'] = 'Monkey See, Monkey Do',
        ['text'] = {
            [1] = 'Each played {C:attention}#1#{} or {C:attention}#2#{} gives {C:red}+8 Mult{}',
            [2] = 'When Scored',
            [3] = '{C:inactive}(ranks change every hand){}'
        }
    },
    pos = {
        x = 1,
        y = 5
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {localize((G.GAME.current_round.rank1_card or {}).rank or 'Ace', 'ranks'), localize((G.GAME.current_round.rank2_card or {}).rank or 'Ace', 'ranks')}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.rank1_card = { rank = 'Ace', id = 14 }
        G.GAME.current_round.rank2_card = { rank = 'King', id = 13 }
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == G.GAME.current_round.rank1_card.id or context.other_card:get_id() == G.GAME.current_round.rank2_card.id) then
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
                if G.playing_cards then
                        local valid_rank1_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_rank1_cards[#valid_rank1_cards + 1] = v
                            end
                        end
                        if valid_rank1_cards[1] then
                            local rank1_card = pseudorandom_element(valid_rank1_cards, pseudoseed('rank1' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.rank1_card.rank = rank1_card.base.value
                            G.GAME.current_round.rank1_card.id = rank1_card.base.id
                        end
                    end
                if G.playing_cards then
                        local valid_rank2_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_rank2_cards[#valid_rank2_cards + 1] = v
                            end
                        end
                        if valid_rank2_cards[1] then
                            local rank2_card = pseudorandom_element(valid_rank2_cards, pseudoseed('rank2' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.rank2_card.rank = rank2_card.base.value
                            G.GAME.current_round.rank2_card.id = rank2_card.base.id
                        end
                    end
        end
    end
}