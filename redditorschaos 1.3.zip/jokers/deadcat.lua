SMODS.Joker{ --Dead Cat
    key = "deadcat",
    config = {
        extra = {
            hands = 9,
            discards = 999999,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Dead Cat',
        ['text'] = {
            [1] = 'Sell this card to gain {C:blue}+9{} hands',
            [2] = 'and lose all {C:red}discards{} for this round'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.selling_self  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hands).." Hand", colour = G.C.GREEN})
                G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + card.ability.extra.hands
                return true
            end,
                    extra = {
                        func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.discards).." Discard", colour = G.C.RED})
                G.GAME.current_round.discards_left = G.GAME.current_round.discards_left - card.ability.extra.discards
                return true
            end,
                        colour = G.C.ORANGE
                        }
                }
        end
    end
}