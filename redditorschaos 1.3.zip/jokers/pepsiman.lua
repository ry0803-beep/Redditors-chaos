SMODS.Joker{ --Pepsi Man
    key = "pepsiman",
    config = {
        extra = {
            odds = 9,
            pepsi = 0
        }
    },
    loc_txt = {
        ['name'] = 'Pepsi Man',
        ['text'] = {
            [1] = 'When you play a {C:attention}Flush{} of {C:clubs}Clubs{}',
            [2] = 'theirs a {C:green}#1# in #2# {}chance you',
            [3] = 'create a {C:dark_edition}Negative{} Pepsi'
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_redditor_pepsiman') 
        return {vars = {card.ability.extra.pepsi, new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (context.scoring_name == "Flush" and (function()
    local allMatchSuit = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:is_suit("Clubs")) then
            allMatchSuit = false
            break
        end
    end
    
    return allMatchSuit and #context.scoring_hand > 0
end)()) then
                if SMODS.pseudorandom_probability(card, 'group_0_09cfc4d6', 1, card.ability.extra.odds, 'j_redditor_pepsiman') then
                      local created_joker = true
                  G.E_MANAGER:add_event(Event({
                      func = function()
                          local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'redditor_pepsi' })
                          if joker_card then
                              joker_card:set_edition("e_negative", true)
                              
                          end
                          
                          return true
                      end
                  }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_joker and localize('k_plus_joker') or nil, colour = G.C.BLUE})
                  end
            end
        end
    end
}