SMODS.Joker{ --Overdrive
    key = "overdrive",
    config = {
        extra = {
            hands = 1,
            Xmult = 2,
            hand_size = 3,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Overdrive',
        ['text'] = {
            [1] = '{C:attention}+3{} hand size,',
            [2] = 'hands cost {C:attention}+1{} more hand to play',
            [3] = '{X:red,C:white}X2{} Mult per hand',
            [4] = 'when this card is sold, {C:red}-3{} hand size'
        }
    },
    pos = {
        x = 5,
        y = 5
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.hands).." Hand", colour = G.C.RED})
                G.GAME.current_round.hands_left = G.GAME.current_round.hands_left - card.ability.extra.hands
                return true
            end,
                    extra = {
                        Xmult = card.ability.extra.Xmult
                        }
                }
        end
        if context.selling_self  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.hand_size).." Hand Size", colour = G.C.RED})
                G.hand:change_size(-card.ability.extra.hand_size)
                return true
            end
                }
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        G.hand:change_size(3)
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.hand:change_size(-3)
    end
}