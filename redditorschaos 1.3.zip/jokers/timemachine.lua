SMODS.Joker{ --Time Machine
    key = "timemachine",
    config = {
        extra = {
            ante_value = 1
        }
    },
    loc_txt = {
        ['name'] = 'Time Machine',
        ['text'] = {
            [1] = 'Sell this card to lower {C:attention}ante{} by {C:attention}1{}'
        }
    },
    pos = {
        x = 5,
        y = 7
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.selling_self  then
                return {
                    func = function()
                    local mod = -card.ability.extra.ante_value
		ease_ante(mod)
		G.E_MANAGER:add_event(Event({
			func = function()
				G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
				return true
			end,
		}))
                    return true
                end,
                    message = "Ante -" .. card.ability.extra.ante_value
                }
        end
    end
}