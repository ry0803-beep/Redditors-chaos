SMODS.Joker{ --Decalcomania
    key = "decalcomania",
    config = {
        extra = {
            odds = 7
        }
    },
    loc_txt = {
        ['name'] = 'Decalcomania',
        ['text'] = {
            [1] = '{C:green}#1# in #2#{} chance to add {C:attention}Foil{},',
            [2] = '{C:attention}Holographic{}, or {C:attention}Polychrome{}',
            [3] = 'to scored {C:attention}cards{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 3
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_redditor_decalcomania') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card.edition == nil then
                if SMODS.pseudorandom_probability(card, 'group_0_aa1cf6e8', 1, card.ability.extra.odds, 'j_redditor_decalcomania') then
                      local random_edition = poll_edition('edit_card_edition', nil, true, true)
                if random_edition then
                    context.other_card:set_edition(random_edition, true)
                end
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
                  end
            end
        end
    end
}