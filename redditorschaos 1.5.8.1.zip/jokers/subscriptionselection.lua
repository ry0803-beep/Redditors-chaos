SMODS.Joker{ --Subscription Selection
    key = "subscriptionselection",
    config = {
        extra = {
            dollars = 3
        }
    },
    loc_txt = {
        ['name'] = 'Subscription Selection',
        ['text'] = {
            [1] = '{C:attention}+5{} card selection limit, each {C:attention}card{} scored costs {C:money}$3{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 12
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                return {
                    dollars = -card.ability.extra.dollars
                }
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        SMODS.change_play_limit(5)
        SMODS.change_discard_limit(5)
    end,

    remove_from_deck = function(self, card, from_debuff)
        SMODS.change_play_limit(-5)
        SMODS.change_discard_limit(-5)
    end
}