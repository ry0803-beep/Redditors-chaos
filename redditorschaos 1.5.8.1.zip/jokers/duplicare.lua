SMODS.Joker{ --Duplicare
    key = "duplicare",
    config = {
        extra = {
            xmult = 1,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Duplicare',
        ['text'] = {
            [1] = 'This Joker gains {X:red,C:white}X0.01{} Mult when a',
            [2] = '{C:attention}Playing card{} is {C:attention}scored{}',
            [3] = '{C:inactive}(currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}',
            [4] = '{C:inactive,s:0.7}(couldn\'t afford the full joker, sorry){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                card.ability.extra.var1 = (card.ability.extra.var1) + 0.01
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.xmult
                }
        end
    end
}