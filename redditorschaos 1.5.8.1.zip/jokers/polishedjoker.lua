SMODS.Joker{ --Polished Joker
    key = "polishedjoker",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Polished Joker',
        ['text'] = {
            [1] = 'Played {C:attention}Stone{} cards Gain {C:attention}Foil{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 10
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_stone"] == true then
                context.other_card:set_edition("e_foil", true)
                return {
                    message = "Card Modified!"
                }
            end
        end
    end
}