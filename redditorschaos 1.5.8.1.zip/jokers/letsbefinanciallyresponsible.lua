SMODS.Joker{ --Lets Be Financially Responsible
    key = "letsbefinanciallyresponsible",
    config = {
        extra = {
            xmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Lets Be Financially Responsible',
        ['text'] = {
            [1] = 'When {C:attention}Blind{} is selected, if you have a {C:tarot}wheel of fortune{}',
            [2] = '{C:red}Destroy{} it and this card gains {X:red,C:white}X0.5{} Mult',
            [3] = '{C:inactive}(currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 8
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.setting_blind  then
            if (function()
    local count = 0
    for _, consumable_card in pairs(G.consumeables.cards or {}) do
        if consumable_card.config.center.key == "c_wheel_of_fortune" then
            count = count + 1
        end
    end
    return count > 0
end)() then
                return {
                    func = function()
            local target_cards = {}
            for i, consumable in ipairs(G.consumeables.cards) do
                if consumable.ability.set == "Tarot" and consumable.config.center.key == "c_fool" then
                    table.insert(target_cards, consumable)
                end
            end
            if #target_cards > 0 then
                local card_to_destroy = pseudorandom_element(target_cards, pseudoseed('destroy_consumable'))
                G.E_MANAGER:add_event(Event({
                    func = function()
                        card_to_destroy:start_dissolve()
                        return true
                    end
                }))
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed Consumable!", colour = G.C.RED})
            end
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.xmult = (card.ability.extra.xmult) + 0.5
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.xmult
                }
        end
    end
}