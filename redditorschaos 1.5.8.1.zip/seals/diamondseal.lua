SMODS.Seal {
    key = 'diamondseal',
    pos = { x = 1, y = 0 },
    config = {
        extra = {
            money÷5 = 0
        }
    },
    badge_colour = HEX('4ECDC4'),
   loc_txt = {
        name = 'Diamond Seal',
        label = 'Diamond Seal',
        text = {
        [1] = 'Earn {C:money}$1{} for every {C:money}$5{} you have if this card',
        [2] = 'is held at the end of round'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.main_scoring and context.end_of_round then
            return { dollars = lenient_bignum(math.floor(lenient_bignum(G.GAME.dollars / 5))) }
        end
    end
}