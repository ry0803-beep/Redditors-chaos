SMODS.Enhancement {
    key = '_3',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            mult = 3,
            chips = 3,
            dollars = 3
        }
    },
    loc_txt = {
        name = ':3',
        text = {
        [1] = 'If this cards rank is a {C:attention}3{}',
        [2] = 'when this card is scored {C:red}+3 Mult{}',
        [3] = '{C:blue}+3 Chips{} {C:money}$3{}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play and card:get_id() == 3 then
            return { mult = card.ability.extra.mult, chips = card.ability.extra.chips, dollars = lenient_bignum(card.ability.extra.dollars) }
        end
    end
}