SMODS.Enhancement {
    key = 'bronze',
    pos = { x = 8, y = 0 },
    config = {
        extra = {
            dollars = 3
        }
    },
    loc_txt = {
        name = 'Bronze',
        text = {
        [1] = 'When this card is {C:red}discarded{} gain {C:money}$3{}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.discard and context.other_card == card  then
            return { dollars = lenient_bignum(card.ability.extra.dollars) }
        end
    end
}