SMODS.Enhancement {
    key = 'plastic',
    pos = { x = 7, y = 1 },
    config = {
        extra = {
            x_mult = 1.5
        }
    },
    loc_txt = {
        name = 'Plastic',
        text = {
        [1] = '{X:red,C:white}X1.5{} Mult',
        [2] = 'this card has no rank'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = true,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return { x_mult = card.ability.extra.x_mult }
        end
    end
}