SMODS.Enhancement {
    key = 'radiant',
    pos = { x = 8, y = 1 },
    loc_txt = {
        name = 'Radiant',
        text = {
        [1] = 'This card always scores'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = true,
    unlocked = true,
    discovered = true,
    no_collection = false
}