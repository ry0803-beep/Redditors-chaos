SMODS.Enhancement {
    key = 'burst',
    pos = { x = 9, y = 0 },
    config = {
        extra = {
            retrigger_times = 5
        }
    },
    loc_txt = {
        name = 'Burst',
        text = {
        [1] = '{C:attention}Retrigger{} this card {C:attention}5{} times',
        [2] = 'and {C:red}Destroy{} it'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    shatters = true,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            return { remove = true }
        end
        if context.repetition and card.should_retrigger then
            return { repetitions = card.ability.extra.retrigger_times }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            card.should_retrigger = false
            card.should_retrigger = true
            card.ability.extra.retrigger_times = 5
            card.should_destroy = true
        end
    end
}