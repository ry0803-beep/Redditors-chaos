SMODS.Consumable {
    key = 'shininglight',
    set = 'Spectral',
    pos = { x = 7, y = 3 },
    loc_txt = {
        name = 'Shining Light',
        text = {
        [1] = '{C:enhanced}Enhance{} {C:attention}2{} selected cards into {C:attention}Radiant{} cards'
    }
    },
    cost = 4,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted < 3 then
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted < 3)
    end
}