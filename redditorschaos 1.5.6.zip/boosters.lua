SMODS.Booster {
    key = 'banana_pack',
    loc_txt = {
        name = "Banana Pack",
        text = {
            "Choose 1 of 3 banana cards"
        },
        group_name = "Banana Pack"
    },
    config = { extra = 3, choose = 1 },
    cost = 6,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            2,
            0.1
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('redditor_banana_pack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
            set = "Playing Card",
            enhancement = "m_redditor_banana",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_banana_pack"
            }
        elseif selected_index == 2 then
            return {
            set = "Playing Card",
            enhancement = "m_redditor_bigbanana",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_banana_pack"
            }
        end
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.3,
            initialize = true,
            lifespan = 3,
            speed = 0.2,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.BLACK, G.C.RED },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'delta_pack',
    loc_txt = {
        name = "Delta Pack",
        text = {
            "Choose between 1 of 3 deltarune jokers"
        },
        group_name = "Delta Pack"
    },
    config = { extra = 3, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 1, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            1,
            0.5,
            2,
            0.5,
            1,
            0.5,
            0.5,
            0.5,
            1,
            1
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('redditor_delta_pack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
            key = "j_redditor_noellewillwatchfromthechair",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_delta_pack"
            }
        elseif selected_index == 2 then
            return {
            key = "j_redditor_chaoschoas",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_delta_pack"
            }
        elseif selected_index == 3 then
            return {
            key = "j_redditor_krisgetthebanana",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_delta_pack"
            }
        elseif selected_index == 4 then
            return {
            key = "j_redditor_potassium",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_delta_pack"
            }
        elseif selected_index == 5 then
            return {
            key = "j_redditor_prophecyjoker",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_delta_pack"
            }
        elseif selected_index == 6 then
            return {
            key = "j_redditor_spamtonneo",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_delta_pack"
            }
        elseif selected_index == 7 then
            return {
            key = "j_redditor_tenna",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_delta_pack"
            }
        elseif selected_index == 8 then
            return {
            key = "j_redditor_thenikelogoofdoomanddespair",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_delta_pack"
            }
        elseif selected_index == 9 then
            return {
            key = "j_redditor_thequeenschariotcannotbestopped",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_delta_pack"
            }
        elseif selected_index == 10 then
            return {
            key = "j_redditor_yourtakingtolong",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_delta_pack"
            }
        end
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'jumbo_delta_pack',
    loc_txt = {
        name = "Jumbo Delta Pack",
        text = {
            "Choose between 1 of 4 deltarune jokers"
        },
        group_name = "Jumbo Delta Pack"
    },
    config = { extra = 4, choose = 1 },
    cost = 6,
    atlas = "CustomBoosters",
    pos = { x = 2, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            1,
            0.5,
            2,
            0.5,
            1,
            0.5,
            0.5,
            0.5,
            1,
            1
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('redditor_jumbo_delta_pack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
            key = "j_redditor_noellewillwatchfromthechair",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_delta_pack"
            }
        elseif selected_index == 2 then
            return {
            key = "j_redditor_chaoschoas",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_delta_pack"
            }
        elseif selected_index == 3 then
            return {
            key = "j_redditor_krisgetthebanana",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_delta_pack"
            }
        elseif selected_index == 4 then
            return {
            key = "j_redditor_potassium",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_delta_pack"
            }
        elseif selected_index == 5 then
            return {
            key = "j_redditor_prophecyjoker",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_delta_pack"
            }
        elseif selected_index == 6 then
            return {
            key = "j_redditor_spamtonneo",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_delta_pack"
            }
        elseif selected_index == 7 then
            return {
            key = "j_redditor_tenna",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_delta_pack"
            }
        elseif selected_index == 8 then
            return {
            key = "j_redditor_thenikelogoofdoomanddespair",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_delta_pack"
            }
        elseif selected_index == 9 then
            return {
            key = "j_redditor_thequeenschariotcannotbestopped",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_delta_pack"
            }
        elseif selected_index == 10 then
            return {
            key = "j_redditor_yourtakingtolong",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_delta_pack"
            }
        end
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'jumbo_mahjong_pack',
    loc_txt = {
        name = "Jumbo Mahjong Pack",
        text = {
            "choose 1 of 4 Mahjong jokers"
        },
        group_name = "Jumbo Mahjong Pack"
    },
    config = { extra = 4, choose = 1 },
    cost = 6,
    atlas = "CustomBoosters",
    pos = { x = 3, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        rarity = "redditor_mahjong",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_jumbo_mahjong_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'jumbo_negative_pack',
    loc_txt = {
        name = "Jumbo Negative Pack",
        text = {
            "Choose 1 of 4 Negative jokers"
        },
        group_name = "Jumbo Negative Pack"
    },
    config = { extra = 4, choose = 1 },
    cost = 12,
    atlas = "CustomBoosters",
    pos = { x = 4, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        edition = "e_negative",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_jumbo_negative_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'jumbo_pride_pack',
    loc_txt = {
        name = "Jumbo Pride Pack",
        text = {
            "Choose 1 of 4 Polychrome jokers"
        },
        group_name = "Jumbo Pride Pack"
    },
    config = { extra = 4, choose = 1 },
    cost = 12,
    atlas = "CustomBoosters",
    pos = { x = 5, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        edition = "e_polychrome",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_jumbo_pride_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mahjong_pack',
    loc_txt = {
        name = "Mahjong Pack",
        text = {
            "choose 1 of 3 Mahjong jokers"
        },
        group_name = "Mahjong Pack"
    },
    config = { extra = 3, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 6, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        rarity = "redditor_mahjong",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_mahjong_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mega_delta_pack',
    loc_txt = {
        name = "Mega Delta Pack",
        text = {
            "Choose between 2 of 4 deltarune jokers"
        },
        group_name = "Mega Delta Pack"
    },
    config = { extra = 4, choose = 2 },
    atlas = "CustomBoosters",
    pos = { x = 7, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            1,
            0.5,
            2,
            0.5,
            1,
            0.5,
            0.5,
            0.5,
            1,
            1
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('redditor_mega_delta_pack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
            key = "j_redditor_noellewillwatchfromthechair",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_delta_pack"
            }
        elseif selected_index == 2 then
            return {
            key = "j_redditor_chaoschoas",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_delta_pack"
            }
        elseif selected_index == 3 then
            return {
            key = "j_redditor_krisgetthebanana",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_delta_pack"
            }
        elseif selected_index == 4 then
            return {
            key = "j_redditor_potassium",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_delta_pack"
            }
        elseif selected_index == 5 then
            return {
            key = "j_redditor_prophecyjoker",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_delta_pack"
            }
        elseif selected_index == 6 then
            return {
            key = "j_redditor_spamtonneo",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_delta_pack"
            }
        elseif selected_index == 7 then
            return {
            key = "j_redditor_tenna",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_delta_pack"
            }
        elseif selected_index == 8 then
            return {
            key = "j_redditor_thenikelogoofdoomanddespair",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_delta_pack"
            }
        elseif selected_index == 9 then
            return {
            key = "j_redditor_thequeenschariotcannotbestopped",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_delta_pack"
            }
        elseif selected_index == 10 then
            return {
            key = "j_redditor_yourtakingtolong",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_delta_pack"
            }
        end
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mega_mahjong_pack',
    loc_txt = {
        name = "Mega Mahjong Pack",
        text = {
            "choose 2 of 4 Mahjong jokers"
        },
        group_name = "Mega Mahjong Pack"
    },
    config = { extra = 4, choose = 2 },
    cost = 8,
    atlas = "CustomBoosters",
    pos = { x = 8, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        rarity = "redditor_mahjong",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_mega_mahjong_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mega_negative_pack',
    loc_txt = {
        name = "Mega Negative Pack",
        text = {
            "Choose 2 of 4 Negative jokers"
        },
        group_name = "Mega Negative Pack"
    },
    config = { extra = 4, choose = 2 },
    cost = 14,
    atlas = "CustomBoosters",
    pos = { x = 9, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        edition = "e_negative",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_mega_negative_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mega_pride_pack',
    loc_txt = {
        name = "Mega Pride Pack",
        text = {
            "Choose 2 of 4 Polychrome jokers"
        },
        group_name = "Mega Pride Pack"
    },
    config = { extra = 4, choose = 2 },
    cost = 16,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 1 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        edition = "e_polychrome",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_mega_pride_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'negative_pack',
    loc_txt = {
        name = "Negative pack",
        text = {
            "Choose 1 of 3 Negative jokers"
        },
        group_name = "Negative pack"
    },
    config = { extra = 3, choose = 1 },
    cost = 10,
    atlas = "CustomBoosters",
    pos = { x = 1, y = 1 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        edition = "e_negative",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_negative_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'pride_pack',
    loc_txt = {
        name = "Pride Pack",
        text = {
            "Choose 1 of 3 Polychrome jokers"
        },
        group_name = "Pride Pack"
    },
    config = { extra = 3, choose = 1 },
    cost = 8,
    atlas = "CustomBoosters",
    pos = { x = 2, y = 1 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        edition = "e_polychrome",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_pride_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'soul_pack',
    loc_txt = {
        name = "Soul Pack",
        text = {
            "There's a soul, nothing else"
        },
        group_name = "Soul Pack"
    },
    config = { extra = 1, choose = 1 },
    cost = 20,
    weight = 0.1,
    atlas = "CustomBoosters",
    pos = { x = 3, y = 1 },
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "soul",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_soul_pack"
        }
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'titan_pack',
    loc_txt = {
        name = "Titan Pack",
        text = {
            "Choose 1 of 3 rare jokers"
        },
        group_name = "Titan Pack"
    },
    config = { extra = 3, choose = 1 },
    cost = 20,
    weight = 0.5,
    atlas = "CustomBoosters",
    pos = { x = 4, y = 1 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        rarity = 3,
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "redditor_titan_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}
