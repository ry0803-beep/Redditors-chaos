SMODS.Joker{ --Power Core
    key = "powercore",
    config = {
        extra = {
            slot_change = 1,
            repetitions = 1,
            hands = 1,
            discards = 1,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Power Core',
        ['text'] = {
            [1] = 'all {C:attention}cards{} get retriggered',
            [2] = '{C:attention}+1{} voucher slots',
            [3] = '{C:attention}+1{} card select limit',
            [4] = '{C:attention}+1{} hands',
            [5] = '{C:attention}+1{} discards',
            [6] = '{C:attention}+1{} Consumable slot',
            [7] = '{C:attention}+1{} booster slot'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 10
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
        end
        if context.setting_blind  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hands).." Hand", colour = G.C.GREEN})
                G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + card.ability.extra.hands
                return true
            end,
                    extra = {
                        func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.discards).." Discard", colour = G.C.ORANGE})
                G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + card.ability.extra.discards
                return true
            end,
                        colour = G.C.ORANGE
                        }
                }
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        SMODS.change_play_limit(1)
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.slot_change
            return true
        end }))
        SMODS.change_voucher_limit(1)
        SMODS.change_booster_limit(1)
        SMODS.change_discard_limit(1)
    end,

    remove_from_deck = function(self, card, from_debuff)
        SMODS.change_play_limit(-1)
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.slot_change
            return true
        end }))
        SMODS.change_voucher_limit(-1)
        SMODS.change_booster_limit(-1)
        SMODS.change_discard_limit(-1)
    end
}