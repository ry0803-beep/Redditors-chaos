SMODS.Joker{ --George
    key = "george",
    config = {
        extra = {
            Xmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'George',
        ['text'] = {
            [1] = 'When a {C:attention}Banana{} card is {C:attention}Scored{} {C:red}Destroy{} it',
            [2] = 'and this card gains {X:red,C:white}X0.1{} Mult',
            [3] = 'When a {C:attention} Big Banana{} card is {C:attention}Scored{} {C:red}Destroy{} it',
            [4] = 'and this card gains {X:red,C:white}X0.3{} Mult',
            [5] = '{C:inactive}(currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 6
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Xmult}}
    end,

    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if SMODS.get_enhancements(context.other_card)["m_redditor_banana"] == true then
                context.other_card.should_destroy = true
                card.ability.extra.Xmult = (card.ability.extra.Xmult) + 0.1
                return {
                    message = "Destroyed!"
                }
            elseif SMODS.get_enhancements(context.other_card)["m_redditor_bigbanana"] == true then
                context.other_card.should_destroy = true
                card.ability.extra.Xmult = (card.ability.extra.Xmult) + 0.1
                return {
                    message = "Destroyed!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.Xmult
                }
        end
    end
}