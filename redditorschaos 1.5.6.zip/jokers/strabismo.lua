SMODS.Joker{ --Strabismo
    key = "strabismo",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Strabismo',
        ['text'] = {
            [1] = 'Copy the effects of the {C:attention}left{} and {C:attention}right{} jokers'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 12
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers'
}