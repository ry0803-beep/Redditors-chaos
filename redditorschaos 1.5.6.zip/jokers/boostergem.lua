SMODS.Joker{ --Booster Gem
    key = "boostergem",
    config = {
        extra = {
            perma_bonus = 5,
            perma_bonus2 = 5,
            perma_bonus3 = 0.1,
            perma_bonus4 = 0.1,
            perma_bonus = 0,
            perma_mult = 0,
            perma_x_chips = 0,
            perma_x_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Booster Gem',
        ['text'] = {
            [1] = 'Every {C:attention}card{} permanently',
            [2] = 'gains {C:red}+5 Mult{}, {C:blue}+5 Chips{}, {X:blue,C:white}X0.1{} Chips',
            [3] = 'and {X:red,C:white}X0.1{} Mult when scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus or 0
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus + card.ability.extra.perma_bonus
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.extra.perma_bonus2
                context.other_card.ability.perma_x_chips = context.other_card.ability.perma_x_chips or 0
                context.other_card.ability.perma_x_chips = context.other_card.ability.perma_x_chips + card.ability.extra.perma_bonus3
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult or 0
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult + card.ability.extra.perma_bonus4
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card,
                    extra = {
                        extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card,
                        colour = G.C.CHIPS,
                        extra = {
                            extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card,
                            colour = G.C.CHIPS,
                        extra = {
                            extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card,
                            colour = G.C.CHIPS
                        }
                        }
                        }
                }
        end
    end
}