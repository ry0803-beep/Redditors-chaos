SMODS.Enhancement {
    key = 'spectral',
    pos = { x = 5, y = 1 },
    config = {
        extra = {
            odds = 5
        }
    },
    loc_txt = {
        name = 'Spectral',
        text = {
        [1] = 'When this card is held in hand',
        [2] = 'at the end of round {C:green}#1# in #2#{}',
        [3] = 'chance to create a {C:spectral}Spectral{} card'
    }
    },
    atlas = 'CustomEnhancements',
    pos = { x = 0, y = 0 },
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'm_redditor_spectral')
        return {vars = {numerator, denominator}}
    end,
    calculate = function(self, card, context)
        if context.end_of_round and context.cardarea == G.hand and context.other_card == card then
            if SMODS.pseudorandom_probability(card, 'group_0_e586c426', 1, card.ability.extra.odds, 'm_redditor') then
                SMODS.calculate_effect({func = function()local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Spectral', key_append = 'enhanced_card_spectral'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+1 Consumable!", colour = G.C.SECONDARY_SET.Spectral})
                    end
                    return true
                end}, card)
            end
        end
    end
}