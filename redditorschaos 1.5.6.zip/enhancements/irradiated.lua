SMODS.Enhancement {
    key = 'irradiated',
    pos = { x = 0, y = 1 },
    config = {
        extra = {
            x_mult = 3,
            odds = 5
        }
    },
    loc_txt = {
        name = 'Irradiated',
        text = {
        [1] = '{X:red,C:white}X3{} Mult',
        [2] = '{C:green}#1# in #2#{} chance to destroy a random joker'
    }
    },
    atlas = 'CustomEnhancements',
    pos = { x = 0, y = 0 },
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'm_redditor_irradiated')
        return {vars = {numerator, denominator}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(card, 'group_0_e3ef4655', 1, card.ability.extra.odds, 'm_redditor') then
                local destructable_jokers = {}
                for i, joker in ipairs(G.jokers.cards) do
                    if not joker.ability.eternal and not joker.getting_sliced then
                        table.insert(destructable_jokers, joker)
                    end
                end
                local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker_enhanced')) or nil
                
                if target_joker then
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                end
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed Joker!", colour = G.C.RED})
            end
            return { x_mult = card.ability.extra.x_mult }
        end
    end
}