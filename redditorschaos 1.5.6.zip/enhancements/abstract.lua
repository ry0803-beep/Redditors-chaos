SMODS.Enhancement {
    key = 'abstract',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            jokercount = 0
        }
    },
    loc_txt = {
        name = 'Abstract',
        text = {
        [1] = '{C:red}+3{} Mult for each {C:attention}Joker{} card',
        [2] = 'when this card is scored',
        [3] = '{C:inactive}(Currently{} {C:red}+#1#{} {C:inactive}Mult){}'
    }
    },
    atlas = 'CustomEnhancements',
    pos = { x = 0, y = 0 },
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        return {vars = {(#(G.jokers and (G.jokers and G.jokers.cards or {}) or {})) * 3}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return { mult = (#(G.jokers and G.jokers.cards or {})) * 3 }
        end
    end
}