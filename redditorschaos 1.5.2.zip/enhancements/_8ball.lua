SMODS.Enhancement {
    key = '_8ball',
    pos = { x = 1, y = 0 },
    loc_txt = {
        name = '8 ball',
        text = {
        [1] = 'If this card rank is an {C:attention}8{}',
        [2] = 'Create a {C:tarot}tarot{} card when this',
        [3] = 'card is {C:attention}scored{}'
    }
    },
    atlas = 'CustomEnhancements',
    pos = { x = 0, y = 0 },
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play and card:get_id() == 8 then
            local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Tarot', key_append = 'enhanced_card_tarot'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_consumable and "+1 Consumable!" or nil, colour = G.C.PURPLE})
        end
    end
}