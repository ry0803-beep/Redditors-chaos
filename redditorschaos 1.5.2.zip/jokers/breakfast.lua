SMODS.Joker{ --Breakfast
    key = "breakfast",
    config = {
        extra = {
            chips = 31
        }
    },
    loc_txt = {
        ['name'] = 'Breakfast',
        ['text'] = {
            [1] = '{C:blue}+31 Chips{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 6,
        y = 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chips
                }
        end
    end
}