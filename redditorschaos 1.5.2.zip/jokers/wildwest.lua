SMODS.Joker{ --Wild West
    key = "wildwest",
    config = {
        extra = {
            xmult = 1,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Wild West',
        ['text'] = {
            [1] = 'This card gains {X:red,C:white}X0.2{} Mult if',
            [2] = '{C:attention}Played hand{} contains a scored {C:attention}Wild{} card',
            [3] = '{C:inactive}(currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 13
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_wild"] == true then
            count = count + 1
        end
    end
    return count >= 1
end)() then
                card.ability.extra.var1 = (card.ability.extra.var1) + 0.2
            else
                return {
                    Xmult = card.ability.extra.xmult
                }
            end
        end
    end
}