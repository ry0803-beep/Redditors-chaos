SMODS.Joker{ --Bury The Light
    key = "burythelight",
    config = {
        extra = {
            Xmult = 1.2
        }
    },
    loc_txt = {
        ['name'] = 'Bury The Light',
        ['text'] = {
            [1] = '{C:attention}Burst{} cards give {X:red,C:white}X1.2{} Mult',
            [2] = 'each time they trigger'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_redditor_burst"] == true then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}