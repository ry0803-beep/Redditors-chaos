SMODS.Joker{ --Nice
    key = "nice",
    config = {
        extra = {
            chips = 69
        }
    },
    loc_txt = {
        ['name'] = 'Nice',
        ['text'] = {
            [1] = 'If {C:attention}Played hand{} contains {C:attention}6{} and {C:attention}9{}',
            [2] = 'gain {C:blue}+69 Chips{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 8
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 6 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)() and (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 9 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)()) then
                return {
                    chips = card.ability.extra.chips,
                    message = "Nice"
                }
            end
        end
    end
}