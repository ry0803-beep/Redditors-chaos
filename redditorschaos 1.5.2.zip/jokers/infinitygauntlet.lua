SMODS.Joker{ --Infinity Gauntlet
    key = "infinitygauntlet",
    config = {
        extra = {
            slot_change = 3,
            emult = 2,
            repetitions = 2,
            perma_bonus = 50,
            perma_bonus2 = 50,
            perma_bonus3 = 0.5,
            perma_bonus4 = 0.5,
            hands = 3,
            discards = 3,
            Spectral = 0,
            respect = 0,
            perma_bonus = 0,
            perma_mult = 0,
            perma_x_chips = 0,
            perma_x_mult = 0,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Infinity Gauntlet',
        ['text'] = {
            [1] = '{X:red,C:white}^2{} Mult',
            [2] = 'all {C:attention}cards{} get retriggered twice',
            [3] = '{C:attention}+3{} voucher slots',
            [4] = '{C:attention}+3{} card select limit',
            [5] = '{C:attention}+3{} hands',
            [6] = '{C:attention}+3{} discards',
            [7] = '{C:attention}+3{} Consumable slot',
            [8] = '{C:attention}+3{} booster slot',
            [9] = 'Every {C:attention}card{} permanently',
            [10] = 'gains {C:red}+50 Mult{}, {C:blue}+50 Chips{}, {X:blue,C:white}X0.5{} Chips',
            [11] = 'and {X:red,C:white}X0.5{} Mult when scored',
            [12] = 'When a hand is played gain {C:attention}2{} {C:dark_edition}Negative{} {C:spectral}Spectral{}',
            [13] = 'cards and a {C:dark_edition}Negative{} {C:attention}Joker{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 6
    },
    cost = 4,
    rarity = "redditor_fusion",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                local created_consumable = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.add_card{set = 'Spectral', key = nil, edition = 'e_negative', key_append = 'joker_forge_spectral'}
                        return true
                    end
                }))
                local created_consumable = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.add_card{set = 'Spectral', key = nil, edition = 'e_negative', key_append = 'joker_forge_spectral'}
                        return true
                    end
                }))
                local created_joker = true
                  G.E_MANAGER:add_event(Event({
                      func = function()
                          local joker_card = SMODS.add_card({ set = 'Joker' })
                          if joker_card then
                              joker_card:set_edition("e_negative", true)
                              
                          end
                          
                          return true
                      end
                  }))
                return {
                    e_mult = card.ability.extra.emult,
                    extra = {
                        message = created_consumable and localize('k_plus_spectral') or nil,
                        colour = G.C.SECONDARY_SET.Spectral,
                        extra = {
                            message = created_consumable and localize('k_plus_spectral') or nil,
                            colour = G.C.SECONDARY_SET.Spectral,
                        extra = {
                            message = created_joker and localize('k_plus_joker') or nil,
                            colour = G.C.BLUE
                        }
                        }
                        }
                }
        end
        if context.repetition and context.cardarea == G.play  then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
        end
        if context.individual and context.cardarea == G.play  then
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus or 0
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus + card.ability.extra.perma_bonus
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.extra.perma_bonus2
                context.other_card.ability.perma_x_chips = context.other_card.ability.perma_x_chips or 0
                context.other_card.ability.perma_x_chips = context.other_card.ability.perma_x_chips + card.ability.extra.perma_bonus3
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult or 0
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult + card.ability.extra.perma_bonus4
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card,
                    extra = {
                        extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card,
                        colour = G.C.CHIPS,
                        extra = {
                            extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card,
                            colour = G.C.CHIPS,
                        extra = {
                            extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card,
                            colour = G.C.CHIPS
                        }
                        }
                        }
                }
        end
        if context.setting_blind  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hands).." Hand", colour = G.C.GREEN})
                G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + card.ability.extra.hands
                return true
            end,
                    extra = {
                        func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.discards).." Discard", colour = G.C.ORANGE})
                G.GAME.current_round.discards_left = G.GAME.current_round.discards_left + card.ability.extra.discards
                return true
            end,
                        colour = G.C.ORANGE
                        }
                }
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        SMODS.change_play_limit(3)
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.slot_change
            return true
        end }))
        SMODS.change_voucher_limit(3)
        SMODS.change_booster_limit(3)
    end,

    remove_from_deck = function(self, card, from_debuff)
        SMODS.change_play_limit(-3)
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.slot_change
            return true
        end }))
        SMODS.change_voucher_limit(-3)
        SMODS.change_booster_limit(-3)
    end
}