SMODS.Joker{ --Chud Joker
    key = "chudjoker",
    config = {
        extra = {
            set_probability = 1,
            set_probability2 = 1,
            numerator = 0,
            denominator = 0
        }
    },
    loc_txt = {
        ['name'] = 'Chud Joker',
        ['text'] = {
            [1] = 'All {C:attention}Listed{} Probabilitys will not happen'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.fix_probability  then
        local numerator, denominator = context.numerator, context.denominator
                numerator = card.ability.extra.set_probability
                denominator = card.ability.extra.set_probability2
      return {
        numerator = numerator, 
        denominator = denominator
      }
        end
    end
}