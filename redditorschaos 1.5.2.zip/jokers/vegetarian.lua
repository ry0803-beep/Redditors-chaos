SMODS.Joker{ --Vegetarian
    key = "vegetarian",
    config = {
        extra = {
            Chips = 0
        }
    },
    loc_txt = {
        ['name'] = 'Vegetarian',
        ['text'] = {
            [1] = 'This card gains {C:blue}+20 Chips{}',
            [2] = 'when a {C:attention}Blind{} is selected.',
            [3] = 'This card resets when a',
            [4] = '{C:attention}consumable{} is used',
            [5] = '{C:inactive}(currently {C:blue}+#1#{} {C:inactive}Chips){}{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 12
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Chips}}
    end,

    calculate = function(self, card, context)
        if context.setting_blind  then
                return {
                    func = function()
                    card.ability.extra.Chips = (card.ability.extra.Chips) + 20
                    return true
                end
                }
        end
        if context.using_consumeable  then
                return {
                    func = function()
                    card.ability.extra.Chips = 0
                    return true
                end
                }
        end
    end
}