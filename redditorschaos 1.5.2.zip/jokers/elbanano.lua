SMODS.Joker{ --El Banano
    key = "elbanano",
    config = {
        extra = {
            odds = 6,
            odds2 = 1000
        }
    },
    loc_txt = {
        ['name'] = 'El Banano',
        ['text'] = {
            [1] = '{C:green}#1# in #2#{} chance of making a {C:attention}scored{} {C:attention}Banana{}',
            [2] = 'card into a {C:attention}Big Banana{} card',
            [3] = '{C:green}#3# in #4#{} chance this card {C:red}Destroys{}',
            [4] = 'itself at the end of round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 3
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 0,
        y = 4
    },

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_redditor_elbanano')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_redditor_elbanano')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_redditor_banana"] == true then
                if SMODS.pseudorandom_probability(card, 'group_0_2c87bd01', 1, card.ability.extra.odds, 'j_redditor_elbanano') then
                      context.other_card:set_ability(G.P_CENTERS.m_redditor_bigbanana)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
                  end
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_0ebf010f', 1, card.ability.extra.odds, 'j_redditor_elbanano') then
                      SMODS.calculate_effect({func = function()
                card:start_dissolve()
                return true
            end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Extinct", colour = G.C.RED})
                  end
            end
        end
    end
}