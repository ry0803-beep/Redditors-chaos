SMODS.Joker{ --All Terminals
    key = "allterminals",
    config = {
        extra = {
            xmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'All Terminals',
        ['text'] = {
            [1] = 'This card gains {X:red,C:white}X0.2{} Mult',
            [2] = 'for each played hand',
            [3] = 'with only {C:attention}Face cards{} or {C:attention}Aces{}',
            [4] = '{C:inactive}(currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
    local allMatchRank = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:is_face()) then
            allMatchRank = false
            break
        end
    end
    
    return allMatchRank and #context.scoring_hand > 0
end)() or (function()
    local allMatchRank = true
    for i, c in ipairs(context.scoring_hand) do
        if not (c:get_id() == 14) then
            allMatchRank = false
            break
        end
    end
    
    return allMatchRank and #context.scoring_hand > 0
end)()) then
                card.ability.extra.xmult = (card.ability.extra.xmult) + 0.2
            else
                return {
                    Xmult = card.ability.extra.xmult
                }
            end
        end
    end
}