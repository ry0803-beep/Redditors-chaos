SMODS.Joker{ --Jokerville
    key = "jokerville",
    config = {
        extra = {
            mult = 0,
            xmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Jokerville',
        ['text'] = {
            [1] = '{C:red}+5 Mult {}for every {C:attention}Played Full house{}',
            [2] = '{X:red,C:white}X0.5{} for every {C:attention}Played Flush house{}',
            [3] = '{C:inactive}(currently{} {C:red}+#1#{} {C:inactive}Mult){}',
            [4] = '{C:inactive}(currently{} {X:red,C:white}X#2#{} {C:inactive}Mult){}'
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult, card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if context.scoring_name == "Full House" then
                card.ability.extra.mult = (card.ability.extra.mult) + 5
            elseif context.scoring_name == "Flush House" then
                card.ability.extra.xmult = (card.ability.extra.xmult) + 0.5
            else
                return {
                    mult = card.ability.extra.mult,
                    extra = {
                        Xmult = card.ability.extra.xmult
                        }
                }
            end
        end
    end
}