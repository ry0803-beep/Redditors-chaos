SMODS.Booster {
    key = 'jumbo_mahjong_pack',
    loc_txt = {
        name = "Jumbo Mahjong Pack",
        text = {
            "Choose 1 of 5 Mahjong jokers"
        },
        group_name = "Jumbo Mahjong Pack"
    },
    config = { extra = 5, choose = 1 },
    cost = 6,
    weight = 0.6,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            0.5,
            0.5,
            1,
            0.5,
            0.5,
            1,
            1
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('redditor_jumbo_mahjong_pack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
            key = "j_allgreen",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_mahjong_pack"
            }
        elseif selected_index == 2 then
            return {
            key = "j_allterminals",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_mahjong_pack"
            }
        elseif selected_index == 3 then
            return {
            key = "j_commonends",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_mahjong_pack"
            }
        elseif selected_index == 4 then
            return {
            key = "j_bigdragons",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_mahjong_pack"
            }
        elseif selected_index == 5 then
            return {
            key = "j_fourconcealedtriplets",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_mahjong_pack"
            }
        elseif selected_index == 6 then
            return {
            key = "j_littledragons",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_mahjong_pack"
            }
        elseif selected_index == 7 then
            return {
            key = "j_reddora",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_jumbo_mahjong_pack"
            }
        end
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("6f2323"))
        ease_background_colour({ new_colour = HEX('6f2323'), special_colour = HEX("ff0000"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mahjong_pack',
    loc_txt = {
        name = "Mahjong Pack",
        text = {
            "Choose 1 of 3 Mahjong jokers"
        },
        group_name = "Mahjong Pack"
    },
    config = { extra = 3, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 1, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            0.5,
            0.5,
            1,
            0.5,
            0.5,
            1,
            1
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('redditor_mahjong_pack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
            key = "j_allgreen",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mahjong_pack"
            }
        elseif selected_index == 2 then
            return {
            key = "j_allterminals",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mahjong_pack"
            }
        elseif selected_index == 3 then
            return {
            key = "j_commonends",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mahjong_pack"
            }
        elseif selected_index == 4 then
            return {
            key = "j_bigdragons",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mahjong_pack"
            }
        elseif selected_index == 5 then
            return {
            key = "j_fourconcealedtriplets",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mahjong_pack"
            }
        elseif selected_index == 6 then
            return {
            key = "j_littledragons",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mahjong_pack"
            }
        elseif selected_index == 7 then
            return {
            key = "j_reddora",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mahjong_pack"
            }
        end
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("6f2323"))
        ease_background_colour({ new_colour = HEX('6f2323'), special_colour = HEX("ff0000"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mega_mahjong_pack',
    loc_txt = {
        name = "Mega Mahjong Pack",
        text = {
            "Choose 2 of 5 Mahjong jokers"
        },
        group_name = "Mega Mahjong Pack"
    },
    config = { extra = 5, choose = 2 },
    cost = 8,
    weight = 0.2,
    atlas = "CustomBoosters",
    pos = { x = 2, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            0.5,
            0.5,
            1,
            0.5,
            0.5,
            1,
            1
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('redditor_mega_mahjong_pack_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
            key = "j_allgreen",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_mahjong_pack"
            }
        elseif selected_index == 2 then
            return {
            key = "j_allterminals",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_mahjong_pack"
            }
        elseif selected_index == 3 then
            return {
            key = "j_commonends",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_mahjong_pack"
            }
        elseif selected_index == 4 then
            return {
            key = "j_bigdragons",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_mahjong_pack"
            }
        elseif selected_index == 5 then
            return {
            key = "j_fourconcealedtriplets",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_mahjong_pack"
            }
        elseif selected_index == 6 then
            return {
            key = "j_littledragons",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_mahjong_pack"
            }
        elseif selected_index == 7 then
            return {
            key = "j_reddora",
            set = "Joker",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "redditor_mega_mahjong_pack"
            }
        end
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("6f2323"))
        ease_background_colour({ new_colour = HEX('6f2323'), special_colour = HEX("ff0000"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}
