SMODS.ConsumableType {
    key = 'soul',
    primary_colour = HEX('666666'),
    secondary_colour = HEX('666666'),
    collection_rows = { 4, 5 },
    shop_rate = 1,
    cards = {
        ['c_redditor_thesoul20'] = true
    },
    loc_txt = {
        name = "Soul",
        collection = "Soul Cards",
    }
}