SMODS.Joker{ --Legennacci
    key = "legennacci",
    config = {
        extra = {
            mult = 8
        }
    },
    loc_txt = {
        ['name'] = 'Legennacci',
        ['text'] = {
            [1] = 'Each played {C:attention}Ace{}, {C:attention}2{}, {C:attention}3{}, {C:attention}5{}, or {C:attention}8{}',
            [2] = 'gives {C:red}+#1#{} Mult when scored and Gives this card',
            [3] = '{C:red}+8 Mult{} per Fibonacci card scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 8
    },
    cost = 5,
    rarity = "redditor_fusion",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',

    in_pool = function(self, args)
        return args.source ~= 'sho'
    end,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.mult}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 2 and context.other_card:get_id() == 3 and context.other_card:get_id() == 5 and context.other_card:get_id() == 8 and context.other_card:get_id() == 14) then
                local mult_value = card.ability.extra.mult
                card.ability.extra.mult = (card.ability.extra.mult) + 8
                return {
                    mult = mult_value
                }
            end
        end
    end
}