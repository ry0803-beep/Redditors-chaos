SMODS.Joker{ --Mr Business
    key = "mrbusiness",
    config = {
        extra = {
            money = 0,
            currentmoney = 0
        }
    },
    loc_txt = {
        ['name'] = 'Mr Business',
        ['text'] = {
            [1] = 'Gain {C:money}1/4{} of your money',
            [2] = 'at the end of shop',
            [3] = '{C:inactive}(currently{} {C:money}$#2#{}{C:inactive}){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 9
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    soul_pos = {
        x = 1,
        y = 9
    },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.money, ((G.GAME.dollars or 0)) * 0.25}}
    end,

    calculate = function(self, card, context)
        if context.ending_shop  then
                return {
                    dollars = (G.GAME.dollars) * 0.25
                }
        end
    end
}