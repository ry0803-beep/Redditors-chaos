SMODS.Joker{ --Cerberus
    key = "cerberus",
    config = {
        extra = {
            Xmult = 5
        }
    },
    loc_txt = {
        ['name'] = 'Cerberus',
        ['text'] = {
            [1] = 'On {C:attention}Boss Blinds{}, {X:red,C:white}X5{} Mult if {C:attention}Played hand{}',
            [2] = 'contains a {C:attention}Two Pair{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (G.GAME.blind.boss and next(context.poker_hands["Two Pair"])) then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}