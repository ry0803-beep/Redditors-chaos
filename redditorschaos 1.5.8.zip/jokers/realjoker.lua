SMODS.Joker{ --Real Joker
    key = "realjoker",
    config = {
        extra = {
            xmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Real Joker',
        ['text'] = {
            [1] = 'This joker gains {X:red,C:white}X0.1{} Mult',
            [2] = 'per card {C:red}destroyed{}',
            [3] = '{C:inactive}(currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 5,
        y = 11
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.remove_playing_cards  then
                return {
                    func = function()
                    card.ability.extra.xmult = (card.ability.extra.xmult) + 0.1
                    return true
                end
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.xmult
                }
        end
    end
}