SMODS.Joker{ --Chili Pepper
    key = "chilipepper",
    config = {
        extra = {
            number = 5,
            odds = 5,
            pb_mult_0d481819 = 4,
            perma_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Chili Pepper',
        ['text'] = {
            [1] = '{C:green}#3# in #4#{} chance to permanently',
            [2] = 'give scored cards {C:red}+4 Mult{}',
            [3] = '{C:inactive}(Probability decreases by{} {C:green}1{}',
            [4] = '{C:inactive}at the end of round){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, number, card.ability.extra.odds, 'j_redditor_chilipepper') 
        return {vars = {card.ability.extra.number, card.ability.extra.perma_mult, new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_88c32b60', 1, card.ability.extra.odds, 'j_redditor_chilipepper') then
                      context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.extra.pb_mult_0d481819
                        SMODS.calculate_effect({extra = { message = localize('k_upgrade_ex'), colour = G.C.MULT }, card = card}, card)
                  end
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                    card.ability.extra.number = math.max(0, (card.ability.extra.number) - 1)
                    return true
                end
                }
        end
        if context.setting_blind  then
            if (card.ability.extra.number or 0) == 0 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Eaten"
                }
            end
        end
    end
}