SMODS.Enhancement {
    key = 'draw4',
    pos = { x = 0, y = 1 },
    config = {
        extra = {
            odds = 4,
            card_draw = 4
        }
    },
    loc_txt = {
        name = 'Draw 4',
        text = {
        [1] = 'When this card is held in hand',
        [2] = '{C:green}#1# in #2#{} chance to draw {C:attention}4{} cards'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'm_redditor_draw4')
        return {vars = {numerator, denominator}}
    end,
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.main_scoring then
            if SMODS.pseudorandom_probability(card, 'group_0_03e4c870', 1, card.ability.extra.odds, 'm_redditor') then
                if G.GAME.blind.in_blind then
    SMODS.draw_cards(card.ability.extra.card_draw)
  end
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.card_draw).." Cards Drawn", colour = G.C.BLUE})
            end
        end
    end
}