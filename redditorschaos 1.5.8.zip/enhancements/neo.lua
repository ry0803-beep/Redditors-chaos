SMODS.Enhancement {
    key = 'neo',
    pos = { x = 6, y = 1 },
    config = {
        extra = {
            retrigger_times = 2,
            odds = 7,
            dollars = 10
        }
    },
    loc_txt = {
        name = 'NEO',
        text = {
        [1] = '{C:attention}Retrigger{} this card twice',
        [2] = '{C:green}#1# in #2#{} chance of {C:red}-$10{}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'm_redditor_neo')
        return {vars = {numerator, denominator}}
    end,
    calculate = function(self, card, context)
        if context.repetition and card.should_retrigger then
            return { repetitions = card.ability.extra.retrigger_times }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_retrigger = false
            card.should_retrigger = true
            card.ability.extra.retrigger_times = 2
            if SMODS.pseudorandom_probability(card, 'group_0_5bbb3791', 1, card.ability.extra.odds, 'm_redditor') then
                SMODS.calculate_effect({dollars = -lenient_bignum(card.ability.extra.dollars)}, card)
            end
        end
    end
}