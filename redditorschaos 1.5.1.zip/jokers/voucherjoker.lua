SMODS.Joker{ --Voucher Joker
    key = "voucherjoker",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Voucher Joker',
        ['text'] = {
            [1] = '{C:attention}+1{} Voucher slot'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 12
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    add_to_deck = function(self, card, from_debuff)
        SMODS.change_voucher_limit(1)
    end,

    remove_from_deck = function(self, card, from_debuff)
        SMODS.change_voucher_limit(-1)
    end
}