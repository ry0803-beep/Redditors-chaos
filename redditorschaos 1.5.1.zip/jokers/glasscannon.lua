SMODS.Joker{ --Glass Cannon
    key = "glasscannon",
    config = {
        extra = {
            Xmult = 5,
            hands = 1,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Glass Cannon',
        ['text'] = {
            [1] = '{X:red,C:white}X5{} Mult, you only have {C:attention}1{} hand'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 5
    },
    cost = 5,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.Xmult
                }
        end
        if context.setting_blind  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to "..tostring(card.ability.extra.hands).." Hands", colour = G.C.BLUE})
                G.GAME.current_round.hands_left = card.ability.extra.hands
                return true
            end
                }
        end
    end
}