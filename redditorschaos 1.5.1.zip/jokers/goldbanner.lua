SMODS.Joker{ --Gold Banner
    key = "goldbanner",
    config = {
        extra = {
            discardsremaining = 1
        }
    },
    loc_txt = {
        ['name'] = 'Gold Banner',
        ['text'] = {
            [1] = '{X:red,C:white}X1{} Mult for each remaining {C:red}Discard{}',
            [2] = '{C:inactive}(currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 5
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.discardsremaining + ((G.GAME.current_round.discards_left or 0))}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.discardsremaining + (G.GAME.current_round.discards_left)
                }
        end
    end
}