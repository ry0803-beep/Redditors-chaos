SMODS.Joker{ --Circulus Pistoris
    key = "circuluspistoris",
    config = {
        extra = {
            Xmult = 3.14
        }
    },
    loc_txt = {
        ['name'] = 'Circulus Pistoris',
        ['text'] = {
            [1] = 'If hands Equal {C:attention}3{} {X:red,C:white}X3.14{} Mult',
            [2] = '{C:inactive,s:0.7}(you need $314159265358979323846 to get the full joker){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.current_round.hands_left == 3 then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}