SMODS.Joker{ --Like An10nes To Heaven
    key = "likean10nestoheaven",
    config = {
        extra = {
            xmult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Like An10nes To Heaven',
        ['text'] = {
            [1] = 'This card Gains {X:red,C:white}X0.2{} Mult Per {C:attention}10{} Scored',
            [2] = '{C:inactive}(currently at{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 6
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.xmult}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 10 then
                card.ability.extra.xmult = (card.ability.extra.xmult) + 0.2
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.xmult
                }
        end
    end
}