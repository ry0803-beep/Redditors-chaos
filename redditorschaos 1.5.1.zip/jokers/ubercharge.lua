SMODS.Joker{ --Ubercharge
    key = "ubercharge",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Ubercharge',
        ['text'] = {
            [1] = 'All {C:attention}scored{} cards become {C:attention}Burst{} cards'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 11
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                context.other_card:set_ability(G.P_CENTERS.m_redditor_burst)
                return {
                    message = "Card Modified!"
                }
        end
    end
}