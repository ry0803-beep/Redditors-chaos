SMODS.Joker{ --Numberology
    key = "numberology",
    config = {
        extra = {
            Planet = 0
        }
    },
    loc_txt = {
        ['name'] = 'Numberology',
        ['text'] = {
            [1] = 'Create a random {C:planet}Planet{} card if hand contains',
            [2] = 'A {C:attention}Three of a Kind{} of A {C:attention}numbered card{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 7
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 2 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 3
end)() or (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 3 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 3
end)() or (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 4 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 3
end)() or (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 5 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 3
end)() or (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 6 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 3
end)() or (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 7 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 3
end)() or (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 8 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 3
end)() or (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 9 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 3
end)() or (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 10 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 3
end)()) then
                local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Planet', key = nil, key_append = 'joker_forge_planet'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                return {
                    message = created_consumable and localize('k_plus_planet') or nil
                }
            end
        end
    end
}