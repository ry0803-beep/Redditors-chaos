SMODS.Enhancement {
    key = 'stellar',
    pos = { x = 1, y = 1 },
    config = {
        extra = {
            odds = 8,
            levels = 1
        }
    },
    loc_txt = {
        name = 'Stellar',
        text = {
        [1] = '{C:green}#1# in #2#{} chance to upgrade {C:attention}Played hand{}',
        [2] = 'when scored'
    }
    },
    atlas = 'CustomEnhancements',
    pos = { x = 0, y = 0 },
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    loc_vars = function(self, info_queue, card)
        local numerator, denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'm_redditor_stellar')
        return {vars = {numerator, denominator}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(card, 'group_0_d5ad14dc', 1, card.ability.extra.odds, 'm_redditor') then
                local target_hand
                target_hand = context.scoring_name or "High Card"
                SMODS.calculate_effect({level_up = card.ability.extra.levels,
                level_up_hand = target_hand}, card)
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_level_up_ex'), colour = G.C.RED})
            end
        end
    end
}