SMODS.Joker{ --Draw 4
    key = "draw4",
    config = {
        extra = {
            card_draw = 4
        }
    },
    loc_txt = {
        ['name'] = 'Draw 4',
        ['text'] = {
            [1] = 'When you play exactly {C:attention}4{} scored {C:attention}Wild{} cards',
            [2] = 'draw 4 cards'
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["undefined"] == true then
            count = count + 1
        end
    end
    return count == 4
end)() then
                if G.GAME.blind.in_blind then
    SMODS.draw_cards(card.ability.extra.card_draw)
  end
                return {
                    message = "+"..tostring(card.ability.extra.card_draw).." Cards Drawn"
                }
            end
        end
    end
}