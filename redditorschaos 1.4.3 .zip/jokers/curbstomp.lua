SMODS.Joker{ --Curbstomp
    key = "curbstomp",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Curbstomp',
        ['text'] = {
            [1] = 'When Played hand triggers the {C:attention}Boss blind{},',
            [2] = '{C:red}Disable{} it and {C:red}Destroy{} this joker'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.blind.triggered then
                if G.GAME.blind and G.GAME.blind.boss and not G.GAME.blind.disabled then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.GAME.blind:disable()
                        play_sound('timpani')
                        return true
                    end
                }))
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('ph_boss_disabled'), colour = G.C.GREEN})
            end
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Destroyed!"
                }
            end
        end
    end
}