SMODS.Joker{ --Gormand
    key = "gormand",
    config = {
        extra = {
            slot_change = 1
        }
    },
    loc_txt = {
        ['name'] = 'Gormand',
        ['text'] = {
            [1] = '{C:attention}+1{} consumable slot'
        }
    },
    pos = {
        x = 1,
        y = 4
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    add_to_deck = function(self, card, from_debuff)
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.slot_change
            return true
        end }))
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.slot_change
            return true
        end }))
    end
}