SMODS.Joker{ --Running with Scissors
    key = "runningwithscissors",
    config = {
        extra = {
            blind_size = 2,
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'Running with Scissors',
        ['text'] = {
            [1] = 'Half {C:attention}Blind{} requirement',
            [2] = '{C:green}#1# in #2#{} this joker destroys itself',
            [3] = 'each round'
        }
    },
    pos = {
        x = 7,
        y = 7
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_redditor_runningwithscissors') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.setting_blind  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Cut", colour = G.C.GREEN})
                G.GAME.blind.chips = G.GAME.blind.chips / card.ability.extra.blind_size
                G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                G.HUD_blind:recalculate()
                return true
            end
                }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_de8a5efc', 1, card.ability.extra.odds, 'j_redditor_runningwithscissors') then
                      SMODS.calculate_effect({func = function()
                card:start_dissolve()
                return true
            end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                  end
            end
        end
    end
}